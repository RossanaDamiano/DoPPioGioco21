<?php

include '../include/connessione.php';


//http://localhost:8888/Doppiogioco/finale/engine/trovaUnit.php?unit=25&response=panic%20fear&sessione=4&decisione=notpro

$unit = $_GET["unit"];
$response = $_GET["response"];
$sessione = $_GET["sessione"];
$decisione = $_GET["decisione"];
$intensity = $_GET["intensity"];
$contatore = $_GET["contatore"];

//echo "intensity : $intensity";

//prendo l'ultima unit aggiunta, così se la stessa unit viene aggiunta più volte di fila a causa di un reload non ci sono errori (a parte la violazione del grafo della storia)
$sql = "SELECT * FROM `session_has_unit` WHERE `session_idsession` = $sessione AND `position` = $contatore ORDER BY `idsession_has_unit` DESC";
//echo $sql;


if (!($result = mysqli_query($connessione, $sql)))
	 die("Non trovo l'emozione dell'ultima unit inserita nella sessione");
$cont = mysqli_fetch_array($result, MYSQLI_ASSOC);
$response = $cont["response"];

//echo "emozione letta: $response ";

//echo "ultima unit: $unit; response: $response; sessione: $sessione; decisione: $decisione; intensity: $intensity <br/>";


// trovaContinuazioni.php genera dei controlli e *** il pulsante di invio ***  -->

// NO deve passare anche la sessione con hidden e contatore (dopo averlo aggiornato -->

// trova continuazioni

/*
VECCHIE REGOLE
Rabbia: Rabbia, Paura, Disgusto / Gioia
Gioia: Disgusto, Gioia / Tristezza, Rabbia
Tristezza: Tristezza, Disgusto, Paura / Gioia, Rabbia
Paura: Paura, Disgusto / Gioia, Rabbia
Disgusto: Disgusto, Tristezza / Gioia


GRUPPI:

POS HIGH
Amusement
Pride
Joy

POS LOW
Relief
Interest
Pleasure

NEG HIGH
Hot anger
Panic fear
Despair

NEG LOW
Irritation
Anxiety
Sadness

NUOVE REGOLE:

GIOCA A FAVORE: STESSA POLARITà
GIOCA CONTRO: POLARITà INVERSA

CON FLAG POLARITY COME SI VUOLE

*/

$array_emotions = array("amusement" => 1, "pride" => 2, "joy" => 3, "relief" => 4, "interest" => 5, "pleasure" => 6, "hot anger" => 7, "panic fear" => 8, "despair" => 9,  "irritation" => 10, "anxiety" => 11, "sadness" => 12);


$array_emotions_inverse = array(1 => "amusement", 2 => "pride", 3 => "joy", 4 => "relief", 5 => "interest", 6 => "pleasure", 7 => "hot anger", 8 => "panic fear", 9 => "despair", 10 => "irritation", 11 => "anxiety", 12 => "sadness");

//$a = array_fill(5, 6, 'banana');
//$emo_groups[];

$emo_groups = array(1 => "ph", 2 => "ph", 3 => "ph", 4 => "pl", 5 => "pl", 6 => "pl", 7 => "nh", 8 => "nh", 9 => "nh", 10 => "nl", 11 => "nl", 12 => "nl");


//print_r ($emo_groups);

//preparo la query
//SELECT * FROM story_graph JOIN unit	ON `unit_idunit-after` = `idunit` WHERE `unit_idunit-before` = 4 AND `emotion` = 'relief';
//$sql_base = "SELECT * FROM story_graph JOIN unit ON `unit_idunit-after` = `idunit` WHERE `unit_idunit-before` = '$unit'";
$sql_base = "SELECT * FROM (`story_graph` JOIN `unit` ON `unit_idunit-after` = `idunit` ) JOIN `unit_has_emotion` ON `unit_has_emotion`.`id_unit` = `unit`.`idunit` WHERE `in_use` = 1 AND `unit_idunit-before` = '$unit' ";


$emo_number = $array_emotions[$response];
$gruppo_response = $emo_groups[$emo_number];

//echo "emozione $response ha numero $emo_number e appartiene a gruppo $gruppo_response";
//http://localhost:8888/Doppiogioco/beta/engine/step.php?aggiungi=169&sessione=40&contatore=1 (interest)
//ultima unit: 169; response: interest; sessione: 40; decisione: pro; intensity: alta

//prepare the WHERE CLAUSE

//LO SO FA SCHIFO MA PER ORA VA BENE COSI'
switch ($gruppo_response){

	case "ph":
		if ($decisione == "pro") {
			if ($intensity == "alta") {$sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 3 OR `id_emotion` = 4 OR `id_emotion` = 5);";}
			} else {
			//contro!
			if ($intensity == "alta")	{$sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12);";}
			}
		break;

	case "pl":
		if ($decisione == "pro") {
			if ($intensity == "alta") {$sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 3 OR `id_emotion` = 4 OR `id_emotion` = 5);";}
			} else {
			//contro!
			if ($intensity == "alta")	{$sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12);";}
			}
		break;
	case "nh":
		if ($decisione == "pro") {
			if ($intensity == "alta") {$sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12);";}
			} else {
			//contro!
			if ($intensity == "alta")	{$sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 4 OR `id_emotion` = 5 OR `id_emotion` = 6);";}
			}
		break;

	case "nl":
		if ($decisione == "pro") {
			if ($intensity == "alta") {$sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12);";}
			} else {
			//contro!
			if ($intensity == "alta")	{$sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3);";}
				else {$sql = $sql_base . "AND (`id_emotion` = 4 OR `id_emotion` = 5 OR `id_emotion` = 6);";}
			}
		break;
	}

// echo $sql;

if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");	

 	 if (!($result = mysqli_query($connessione, $sql)))
	 die("Non trovo le continuazioni");

$num_rows = mysqli_num_rows($result);
if ($num_rows == 0){die ("mi spiace, non ci sono continuazioni");}
$num_rows_max = $num_rows-1;
$num_extract = rand(0,$num_rows_max);
//echo "risposte possibili a $response ";

// echo "<table>";

$i = 0;
while($unit = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
	if ($i==$num_extract) {
		$title = $unit["title"];
		$title = stripslashes($title);
		$idunit = $unit["idunit"];
		$idemozione = $unit["id_emotion"];
		$emozione = $array_emotions_inverse[$idemozione];
		$immagine = $unit["URI"];
		//  "<tr>";
		// echo "<td><input type=\"radio\" name=\"aggiungi\" value=\"$idunit\" onchange=\"document.getElementById('mandi').disabled = false;\" /> $title ($emozione) </td>";
		// echo "<input type=\"radio\" name=\"aggiungi\" value=\"$idunit\" onchange=\"document.getElementById('mandi').disabled = false;\" /> $title ($emozione)";
		// echo "<input type=\"hidden\" name=\"aggiungi\" value=\"$idunit\" />";
    	$idunit = trim($idunit);
		echo $idunit;
		// echo "<td>";
		// if ($immagine != "") {
		// 	echo "<img id\"=clippy\" style=\"max-width:200px; max-height:200px; width: auto; height: auto;\" src=\"../clips/$immagine\" />";
		// 	}
		// echo "</td>";
		// //echo "<br/>" ;
		// echo "</tr>";
	}
	$i++;
}

// echo "</ table>";

//echo "<input type=\"submit\" value=\"avanti\" /> ";



?>
