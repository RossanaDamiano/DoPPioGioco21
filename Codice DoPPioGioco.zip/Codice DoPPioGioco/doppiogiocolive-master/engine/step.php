<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Author" content="Vincenzo Lombardo">
<meta name="Description" content="www.cirma.unito.it/labidsi">
<meta name="KeyWords" content="Vincenzo Lombardo, Rossana Damiano, Antonio Pizzo, Laboratorio interdisciplinare, DAMS">
<title>Laboratorio di storie interattive</title>

<link href="../labidsi.css" rel="stylesheet" type="text/css" media="screen" />
<link href="labidsi_stage.css" rel="stylesheet" type="text/css" media="screen" />

<script src="../javascriptesterno01.js" type="text/javascript"></script>

<script>

  var pleasant_opponent = "no_value";
  var high_low = "no_value";

  var check = "true";
  var response_check = "false";
  var flag_reload = "false";
  var flag_type = "reload";


  function myTrim(x) {
    return x.replace(/^\s+|\s+$/gm,'');
}


  window.onbeforeunload = function() { if (flag_reload == "false") {return "Confermando il click potresti causare un'anomalia nel sistema. Utilizza i comandi dell'applicazione per navigare invece della barra di navigazione del browser";} };

  function getEmotionalResponse(unit,sessione,contatore) {
    if (check == "false") { return;
        //document.getElementById("risposta").innerHTML = "";
    } else {
      if (window.XMLHttpRequest) { xmlhttp = new XMLHttpRequest();
        // code for IE7+, Firefox, Chrome, Opera, Safari
      } else { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            // code for IE6, IE5
      }
      xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
          document.getElementById("pubblico_grid").innerHTML = xmlhttp.responseText;
          check = "false";
          response_check = "true";
        }
      }
      xmlhttp.open("GET","risposta_pubblico.php?aggiungi="+unit+"&"+"sessione="+sessione+"&"+"contatore="+contatore, true);
      xmlhttp.send();
    }
  }

  function trovaUnit(unit,response,sessione,decisione,intensity,contatore) {
    if (response_check == "false" || high_low == "no_value" || pleasant_opponent == "no_value") { return;
        //document.getElementById("scelta").innerHTML = "";
    } else {
      if (window.XMLHttpRequest) { xmlhttp = new XMLHttpRequest();
        // code for IE7+, Firefox, Chrome, Opera, Safari
      } else { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        // code for IE6, IE5
      }
      xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        	var risultato = myTrim(xmlhttp.responseText);
        	if (risultato == "mi spiace, non ci sono continuazioni"){
        		alert("mi spiace, non ci sono continuazioni");
        		}
        		else {
        			document.prossimo.aggiungi.value = risultato;
        			flag_reload = true;
        			document.getElementById("prox").submit();
        			//alert ("ho settato la prossima clip");
        			}

        }
      }
      //alert("trovaContinuazioni.php?unit="+unit+"&"+"response="+response+"&"+"sessione="+sessione+"&"+"decisione="+decisione+"&"+"intensity="+intensity+"&"+"contatore="+contatore);
      xmlhttp.open("GET","trovaContinuazioni.php?unit="+unit+"&"+"response="+response+"&"+"sessione="+sessione+"&"+"decisione="+decisione+"&"+"intensity="+intensity+"&"+"contatore="+contatore, true);
      xmlhttp.send();
    }
  }
  //funzione js. per gestire la risposta del pubblico
</script>

</head>

<body>
	<div id="titolo">
	  <br/>
	  <h1>- DoPPioGioco Stage -</h1>
	</div>
  <div id="container">
    <!-- Titolo -->
	  <div id="story_title">
	    <div id="homebutton">
	      <a href="../index.php"  onclick="flag_reload='true';"><img src="../immagini/hp_storia.png" width="70" height="25" id="Image2" /></a>
	    </div>
	    Storia: titolo storia
    </div> <!-- div id="story_title" -->

    <!-- Performer -->
    <div id="performer">
			<div id="performer_title">
	      Performer
			</div> <!-- div id="performer_title" -->

      <!-- CLIP A-SX -->
      <div id="clip_stage">
        <!--  RECUPERA TITOLO E UNIT -->
        <?php
          //TO DO: LA STORIA NON FINISCE!!!
          include '../include/connessione.php';
          //if (!(isset[$_GET["sessione"])) die("manca la clip da aggiungere");
          $sessione = $_GET["sessione"];
          $aggiungi = $_GET["aggiungi"];
          $contatore = $_GET["contatore"];
          $current_position = $contatore;
          if (!($connessione = mysqli_connect($host, $username, $password)))
            die("Connessione fallita!");

          if (!(mysqli_select_db($connessione, $db)))
            die("Data base non trovato!");	
          /*
          //stampa sessione fino a ora
          $sql = "SELECT * FROM `session_has_unit` JOIN `unit` ON  `session_has_unit`.`unit_idunit` = `unit`.`idunit` WHERE `session_idsession` = '$sessione' ORDER BY position";
          //echo "lettura sessione: $sql <br/>";
          if (!($result = mysqli_query($connessione, $sql)))
          	 die("Non trovo la lista delle clip");
          $cont = 1;
          while($passo = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
          	$title = $passo["title"];
          	$file = $passo["URI"];
          	$response = $passo["response"];
          	//echo "($cont) clip: <a href=\"clips/$file\">$title</a> - risposta: $response <br/>";
          	$cont++;
          }
          */
          // 1. STAMPO LA UNIT IN INGRESSO
          //1.1 recupero titolo e immagine della unit in ingresso
          $sql = "SELECT * FROM `unit` WHERE `idunit` = '$aggiungi' ";
          if (!($result = mysqli_query($connessione, $sql)))
            die("Non trovo l'ultima unit inserita");
          $u = mysqli_fetch_array($result, MYSQLI_ASSOC);
          $titolo = $u["title"];
          $immagine = $u["URI"];
          $notes = $u['notes'];
          $final = $u['final'];

          $sql = "SELECT * FROM `unit` JOIN `unit_has_emotion` ON `unit_has_emotion`.`id_unit` = `unit`.`idunit` WHERE `id_unit` = '$aggiungi';";
          //echo $sql;

          //1.2 recupero le emozioni associate alla unit
          $emozioni = "";
          if (!($result = mysqli_query($connessione, $sql)))
          	 die("Non trovo le emozioni della clip");

          $array_emotions_inverse = array(1 => "amusement", 2 => "pride", 3 => "joy", 4 => "relief", 5 => "interest", 6 => "pleasure", 7 => "hot anger", 8 => "panic fear", 9 => "despair", 10 => "irritation", 11 => "anxiety", 12 => "sadness");

          while($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
          	$e = $riga["id_emotion"];
          	$name = $array_emotions_inverse[$e];
          	//echo "wow $e";
          	$emozioni = $emozioni . " " . $name;
          }
        ?>
        <div id="cliptitle_stage">
          <?php
          //1.3 stampo titolo
          $titolo = stripslashes($titolo);
          echo "<p><h2>Unit: $titolo ($emozioni) </h2></p>";
          ?>
          <!-- p> Clip title </p -->
        </div>
        <br/><br/>
        <!--<div id="mynotes"> ... </div> -->
        <div id="clipscreen_stage" style="overflow-y:auto">
          <?php
            //1.3 richiamo immagine
            if ($immagine != ""){
              echo "<img id=\"clippy_stage\" name=\"clippy_stage\" position=\"center\" src=\"../clips/$immagine?78532\" />";
            //width=\"scaleSize(\"clips/$metadati[clip]\")[0]\" height=\"scaleSize(\"clips/$metadati[clip]\")[1]\"
            } else {
              echo "<img id=\"clippy_stage\" name=\"clippy_stage\" /><p id=\"notes_mirror\">$notes</p>";
            }
          ?>
        </div> <!-- div id="clipscreen_stage" -->

      </div> <!-- div id="clip_stage" -->

      <!-- div id="risposta">
      </div>
      <hr/ -->

      <div id="azione">

        <table>
          <tr>
            <td colspan="3" align="right" height="40px">  <!-- RESET -->
              <form action="initialize.php">
                <button type="submit" onclick="flag_reload = true;" style="border: 0; background: transparent">
                  <img src="../immagini/ricomincia.png" width="40px" height="40px" alt="submit" />
                </button>
              </form>
            </td>
          </tr>
          <tr>
            <td colspan="3" align="center" height="30px">
              <p><h2>Attitudine verso il pubblico</h2></p>
            </td>
          </tr>
          <tr>
            <td align="center" height="40px">  <!-- pleasant_opponent -->
              <button id="pleasant" name="intens" value="gioca a favore" style="border: 0; background: transparent" onclick="this.style.outline='thick solid #FF0000'; getElementById('opponent').style.outline='none'; pleasant_opponent='pro' ">
                <img src="../immagini/pleasant.png" width="auto" height="40px" alt="high" />
              </button>
              <br/><br/>
              <button id="opponent" name="intens" value="gioca contro" style="border: 0; background: transparent" onclick="this.style.outline='thick solid #FF0000'; getElementById('pleasant').style.outline='none', pleasant_opponent='notpro'">
                <img src="../immagini/opponent.png" width="auto" height="40px" alt="low" />
              </button>
            </td>  <!-- pleasant_opponent -->
            <td align="center" height="40px">  <!-- high_low -->
              <button id="high" name="intens" value="alta" style="border: 0; background: transparent" onclick="this.style.outline='thick solid #FF0000'; getElementById('low').style.outline='none'; high_low='alta'">
                <img src="../immagini/high.png" width="auto" height="40px" alt="submit" />
              </button>
              <br/><br/>
              <button id="low" name="intens" value="bassa" style="border: 0; background: transparent" onclick="this.style.outline='thick solid #FF0000'; getElementById('high').style.outline='none'; high_low='bassa'">
                <img src="../immagini/low.png" width="auto" height="40px" alt="submit" />
              </button>
            </td>  <!-- high_low -->
          </tr>
          <tr>
            <td colspan="3" align="center" height="60px">  <!-- GO -->
              <?php
                echo "<button type=\"submit\" style=\"border: 0; background: transparent\" id=\"mandi\" value=\"avanti\" onclick=\"trovaUnit('$aggiungi','',$sessione,pleasant_opponent,high_low,$contatore);\" />";
              ?>
                <img src="../immagini/go.png" width="auto" height="60px" alt="go" />
              </button>

              <!-- button type="radio" name="intens" value="gioca a favore" style="border: 0; background: transparent" onclick="trovaUnit('$aggiungi','$emozione_cont',$sessione,'pro',document.int.intens.value,$contatore); " -->
            </td>  <!-- GO -->
          </tr>
        </table>
          <!-- tr>
            <td colspan="3" text-align="left">
              <p>Selezione continuazione</p>
            </td>
          </tr -->
          <!-- tr -->
            <form name="prossimo" id="prox" action="step.php">
              <!-- td colspan="2" align="center">
                  < trovaUnit.php DEVE GENERARE dei controlli e il pulsante di invio >
                  <deve passare anche la sessione con hidden e contatore (dopo averlo aggiornato) -->
                <?php
                  $contatore = $contatore + 1;
                  echo "<input type=\"hidden\" name=\"aggiungi\" value=\"\" />";
                  echo "<input type=\"hidden\" name=\"sessione\" value=\"$sessione\"/>";
                  echo "<input type=\"hidden\" name=\"contatore\" value=\"$contatore\"/>";
                ?>
              <!--/td>    -->
              <!-- td align="center" height="50px">   -->

				               <!-- <input type="submit" style="border: 0; background: transparent" id="mandi2" value="avanti" onclick= "flag_reload = true;" />-->
                  <!-- img src="../immagini/go.png" width="auto" height="50px" alt="go" / -->
                <!-- /input -->
              <!-- /td -->
            </form>
          <!-- /tr -->


        <!-- /table -->
      </div> <!-- div id="azione" -->

    </div> <!-- div id="performer" -->

    <div id="pubblico">
      <div id="pubblico_title">
        Pubblico
      </div> <!-- div id="pubblico_title" -->
      <div id="pubblico_grid">
        <?php
          echo "<br/>";
          if ($final == 1) {die ("La storia &egrave; finita (applausi)");}
          echo "<input type=\"button\" value=\"reazione del pubblico\" onclick=\"getEmotionalResponse($aggiungi,$sessione,$current_position);\" >";
        ?>
      </div> <!-- div id="pubblico_grid" -->

    </div> <!-- div id="pubblico" -->

    <footer></footer>
  </div>
</body>
</html>
