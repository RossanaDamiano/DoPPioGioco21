<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="Author" content="Vincenzo Lombardo">
	<meta name="Description" content="www.cirma.unito.it/labidsi">
	<meta name="KeyWords" content="Vincenzo Lombardo, Rossana Damiano, Antonio Pizzo, Laboratorio interdisciplinare, DAMS">
	<title>Laboratorio di storie interattive</title>

	<link href="../labidsi.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="labidsi_stage.css" rel="stylesheet" type="text/css" />

	<script src="../javascriptesterno01.js" type="text/javascript"></script>

</head>

<body>
	<div id="titolo">
	  <br/>
	  <h1>- DoPPioGioco Stage -</h1>
	</div>
  <div id="container">
    <!-- Titolo -->
	  <div id="story_title">
	    <div id="homebutton">
	      <a href="../index.php"><img src="../immagini/hp_storia.png" width="70" height="25" id="Image2" /></a>
	    </div>
	    Storia: titolo storia
    </div> <!-- div id="story_title" -->
    <!-- Performer -->
  	<div id="performer">
			<div id="performer_title">
	      Performer
			</div> <!-- div id="performer_title" -->
      <div id="init_reset_stage">
        <table width=100%>
        <tr><td><p><h2>Scegli clip iniziale</h2></p></td></tr>
        <tr><td>
				<!-- p>Le clip disponibili sono quelle etichettate come iniziali.</p -->
        <form action="step.php">
          <?php
  				  include '../include/connessione.php';
  				  if (!($connessione = mysqli_connect($host, $username, $password)))
							die("Connessione fallita!");

						if (!(mysqli_select_db($connessione, $db)))
							die("Data base non trovato!");	

  					$sql = "SELECT `title`, `idunit` FROM `unit` WHERE `initial` = '1' AND `in_use` = 1;";
  				  echo "<select name=\"aggiungi\">";
  				  if (!($result = mysqli_query($connessione, $sql)))
  					  die("Non trovo la lista delle clip");
  				  while($unit = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
  					  $candidata = $unit["idunit"];
  					  $nome = stripslashes($unit["title"]);
  					  echo "<option value=\"$candidata\" /> $nome </option>";
  				  }
  				  echo "</select>";

  				  $contatore = 1;
  				  $sessione = date("Y-m-d H:i:s");
  				  $sql="INSERT INTO `session` (`timestamp`) VALUES ('$sessione')";
  				  if (!($result = mysqli_query($connessione, $sql)))
  				  	die("Non riesco a creare la sessione");
  				  $sql="SELECT * FROM `session`  WHERE `timestamp` = '$sessione'";
  				  if (!($result = mysqli_query($connessione, $sql)))
  					  die("Non riesco a trovare la sessione iniziale");
  				  $riga = mysqli_fetch_array($result, MYSQLI_ASSOC);
  				  $id_sessione = $riga["idsession"];

  				  //Campo nascosto con sessione
  				  echo "<input type=\"hidden\" name=\"sessione\" value=\"$id_sessione\">";
  				  //Contatore
  				  echo "<input type=\"hidden\" name=\"contatore\" value=\"$contatore\">";
  				?>
          </td></tr>
          <tr><td align="right"><div style="width:50px; height:50px">
          <button type="submit" value="inizia la storia" style="border: 0; background: transparent;">
            <img src="../immagini/go.png" width="50px" height="50px" alt="submit" />
          </button>
          </div>
          </td></tr>
        </form>
        </table>
			</div> <!-- div id="go_performer" -->

		</div> <!-- div id="performer" -->
		<!-- Pubblico -->
		<div id="pubblico">
			<div id="pubblico_title">
			  Pubblico
			</div> <!-- div id="pubblico_title" -->
		</div> <!-- div id="pubblico" -->

  </div> <!-- div id="container" -->

<footer>
</footer>

</body>
</html>
