<?php

$host = "db";

$username = "root";

$password = "root";

$db = "my_labinterdisciplinare1516";

if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");	

?>