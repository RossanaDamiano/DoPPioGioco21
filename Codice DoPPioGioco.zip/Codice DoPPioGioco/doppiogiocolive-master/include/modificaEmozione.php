<?php
include '../include/connessione.php';

$unit = $_REQUEST["unit"];
$flag = $_REQUEST["flag"];
$emotion = $_REQUEST["emotion"];
//echo "il flag vale $flag";

//include '../include/connessione.php';

if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");	


$array_emotions = array("amusement" => 1, "pride" => 2, "joy" => 3, "relief" => 4, "interest" => 5, "pleasure" => 6, "hot anger" => 7, "panic fear" => 8, "despair" => 9,  "irritation" => 10, "anxiety" => 11, "sadness" => 12);
$emotion_id = $array_emotions[$emotion];

if ($flag == 'true'){

	//Se il flag è true, aggiungo l'emozione
	$sql = "SELECT * FROM `unit_has_emotion`JOIN `emotion` ON `emotion`.`idemotion` = `unit_has_emotion`.`id_emotion` WHERE `id_unit` = '$unit' AND `unit_has_emotion`.`id_emotion` = '$emotion_id';";

	if (!($result = mysqli_query($connessione, $sql)))
		 die("Non riesco a leggere l'emozione della clip");

	//verifico che non ci sia già l'emozione,
	if (mysqli_num_rows($result) > 0) {
		die ("emozione già presente");
		}
			else {
				$sql = "INSERT INTO `doppiogioco`.`unit_has_emotion` (`id_unit`, `id_emotion`) VALUES ('$unit', '$array_emotions[$emotion]');";
				if (!($result = mysqli_query($connessione, $sql)))
	 			die("Non riesco a inserire le emozioni!");
				//echo "inserita $emotion a unit $unit";
				echo "<span style=\"color:blue\">$emotion</span>";

			}
	}

	//Se il flag è false, la tolgo
	else {
	$sql = "DELETE FROM `doppiogioco`.`unit_has_emotion` WHERE `unit_has_emotion`.`id_unit` = $unit AND `unit_has_emotion`.`id_emotion` = $emotion_id;";

	if (!($result = mysqli_query($connessione, $sql)))
		 die("Non riesco a cancellare questa emozione");
	//echo "cancellata $emotion a unit $unit";
	echo "<span style=\"color:red\">$emotion</span>";
	}

?>
