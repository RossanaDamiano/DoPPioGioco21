var io = require('socket.io')(14080, {
    //impostazione dei timer
    pingTimeout: 125000,
    pingInterval: 125000
});

var connectedCounter = 0; 

io.use(function(socket, next){

    next();

}).on('connection', function(socket){
    
    //creata la stanza ’doppiogioco’ alla quale accederanno i socket
    var room = "doppiogioco";

    socket.join(room);

    //si tiene conto di quanti socket sono connessi al canale
    connectedCounter++; 
    console.log("Debug: totale connessi: " + connectedCounter);

    //da qui vengono definiti tutti i tipi di messaggi che verranno scambiati
    socket.on("startsessionmsg", function(msg){
        console.log("startsessionmsg received: " + msg);
        io.emit('startsessionmsg', msg);
    });

    socket.on("startmsg", function(msg){
        console.log("startmsg received: " + msg);
        io.emit('startmsg', msg);
    });

    socket.on("takenemotionmsg", function(msg){
        console.log("takenemotionmsg received: " + msg);
        io.emit('takenemotionmsg', msg);
    });

    socket.on("emotionmsg", function(msg){
        console.log("emotionmsg received: " + msg);
        io.emit('emotionmsg', msg);
    });

    socket.on("updatemsg", function(msg){
        console.log("updatemsg received: " + msg);
        io.emit('updatemsg', msg);
    });

    socket.on("endstorymsg", function(msg){
        console.log("endstorymsg received: " + msg);
        io.emit('endstorymsg', msg);
    });

    socket.on("endvideomsg", function(msg){
        console.log("endvideomsg received: " + msg);
        io.emit('endvideomsg', msg);
    });

    socket.on("restartmsg", function(msg){
        console.log("restartmsg received: " + msg);
        io.emit('restartmsg', msg);
    });

    //si tiene conto dei socket che si disconnettono e quanti ne rimangono
    socket.on('disconnect', function(){
        console.log('someone disconnected');
        connectedCounter--;
        console.log("Debug: total users connected: " + connectedCounter);
    });
});