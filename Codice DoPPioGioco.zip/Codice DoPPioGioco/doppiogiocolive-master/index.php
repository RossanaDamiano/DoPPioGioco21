<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Author" content="Vincenzo Lombardo">
<meta name="Description" content="www.cirma.unito.it/labidsi">
<meta name="KeyWords" content="Vincenzo Lombardo, Rossana Damiano, Antonio Pizzo, Laboratorio interdisciplinare, DAMS">
<title>Laboratorio di storie interattive</title>

<link href="labidsi.css" rel="stylesheet" type="text/css" media="screen" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="javascriptesterno01.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.2.0/socket.io.js"></script>

</head>

<body>
<div id="titolo">
  <br/>
  <h1><center>- DoPPioGioco Director -</center></h1>
</div>

<!-- h2 -->

<div id="container">

<!-- QUADRANTE 1 METADATI A-SX -->
  <div id="metadata_home">
    <br />
    <table>
    	<tr><td>Titolo</td><td>Migrazioni</td></tr>
    	<tr><td>Autore</td><td>Corso di Interactive Storytelling, 2018-19</td></tr>
    </table>
    <br />

    <hr />

    <table>
    	<tr><td>Story graph</td><td></td></tr>
    	<tr><td></td><td><a href="director/matrix.php">Table</a></td></tr>
    	<tr><td></td><td><a href="director/story-graph.php">Pairs</a></td></tr>
    	<tr><td></td><td><a href="gestionepubblico/index_audience.php">Gestione pubblico</a></td></tr>
    </table>

    <hr/>
    
    <script>
      const socket = io('http://localhost:14080');
        socket.on('connect', function(){
            console.log("Connessione stabilita globale");
        });
      nuovaSessione();
    </script>
    <table id="table-href">
    	<!-- tr><td></td><td><a href="">Session list</a></td></tr -->
    </table>
    <table id="regia">
    	<!-- tr><td></td><td><a href="">Session list</a></td></tr -->
    </table>

  </div> <!-- Fine Metà Sx -->

  <!-- Inizio Metà DX -->
  <div id="unit_list" style="overflow-y:auto">
    <div>
      <!-- center>Clip title</center -->
      <br />
      <center><p> Unit List </p></center>
    </div>
    <div>
    <br /><br />
<table>

<?php
  include 'include/connessione.php';
  if (!($connessione = mysqli_connect($host, $username, $password)))
    die("Connessione fallita!");

  if (!(mysqli_select_db($connessione, $db)))
    die("Data base non trovato!");	

  $sql = "SELECT `title`, `idunit` FROM `unit` WHERE `in_use` = 1 ORDER BY `title`";
  //echo "$sql";
  if (!($result =  mysqli_query($connessione, $sql)))
	  die("Non riesco a leggere le clip");

  $count = 0;
  while ($unit = mysqli_fetch_array($result)) {
		$title = stripslashes($unit["title"]);
		$id = $unit["idunit"];
    if (fmod($count,4) == 0){echo "<tr><td>";} else {echo "<td>";}
		echo "<form action=\"director/index_unit.php\">";
		echo "<input type=\"hidden\" name=\"unit\" value=\"$id\" />";
		echo "<input type=\"submit\" style=\"color:#000000; background-color: #CCCCCC;\" value=\"$title\" /> <br/ >";
		echo "</form>";
    if (fmod($count,4) == 3){echo "</td></tr>";} else {echo "</td>";}
		$count++;
  }

  if (fmod($count,4) == 0){echo "<tr><td>";} else {echo "<td>";}
  echo "<form action=\"director/index_unit.php\">";
  echo "<input style=\"color:#FF0000; background-color:#CCCCCC;\" type=\"submit\" value=\"new unit\">";
  echo "</form>";
  echo "</td></tr>";
?>
</table>

    </div>

  </div>

</div>

<!-- /h2 -->




</body>
</html>
