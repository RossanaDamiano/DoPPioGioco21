var io = require('socket.io')(14080, {
    pingTimeout: 125000,
    pingInterval: 125000
});

var connectedCounter = 0; 

io.use(function(socket, next){

    next();

}).on('connection', function(socket){
    
    var room = "doppiogioco";

    socket.join(room);
    connectedCounter++; 
    console.log("Debug: ne abbiamo uno nuovo, totale connessi: " + connectedCounter);

    socket.on("startsessionmsg", function(msg){
        console.log("startsessionmsg received: " + msg);
        io.emit('startsessionmsg', msg);
    });

    socket.on("startmsg", function(msg){
        console.log("startmsg received: " + msg);
        io.emit('startmsg', msg);
    });

    socket.on("takenemotionmsg", function(msg){
        console.log("takenemotionmsg received: " + msg);
        io.emit('takenemotionmsg', msg);
    });

    socket.on("emotionmsg", function(msg){
        console.log("emotionmsg received: " + msg);
        io.emit('emotionmsg', msg);
    });

    socket.on("consolemsg", function(msg){
        console.log("consolemsg received: " + msg);
        io.emit('consolemsg', msg);
    });

    socket.on("updatemsg", function(msg){
        console.log("updatemsg received: " + msg);
        io.emit('updatemsg', msg);
    });

    socket.on("endstorymsg", function(msg){
        console.log("endstorymsg received: " + msg);
        io.emit('endstorymsg', msg);
    });

    socket.on("endvideomsg", function(msg){
        console.log("endvideomsg received: " + msg);
        io.emit('endvideomsg', msg);
    });

    socket.on("restartmsg", function(msg){
        console.log("restartmsg received: " + msg);
        io.emit('restartmsg', msg);
    });

    socket.on('disconnect', function(){
        console.log('someone disconnected');
        connectedCounter--;
        console.log("Debug: total users connected: " + connectedCounter);
    });
});