/***************************************************************************************
* Codice per creare i frame del video dato in input                                    *
* I frame vengono creati ogni 2 secondi finchè non finisce il video                    *
* Utilizzo questi frame come immagini e uso le API Face per catturare le emozioni      *
****************************************************************************************/

var stop = "false";

//controllo il tempo del video
function getFrame(){
    stop="false";
    var video = document.getElementById('clippy_stage');
    video.onplay = function (){
        console.log("Durata video: "+video.duration+" start emozioni: "+(video.duration-17));
        video.ontimeupdate = function() {myFunction(video,(video.duration-17))};
    }
    console.log(stop);
}

function fineStoria(){
    var msg = "finevideo";
    socket.emit('endvideomsg', msg);
    console.log("comunico che è finito l'ultimo video");
}

//a metà video salvo nel DB (tramite emotion.php) le info sul video
//corrente, sblocco così le API che cominciano a lavorare
function myFunction(video, timeEmotion) {
    //document.getElementById("demo").innerHTML = video.currentTime;
    if((video.currentTime >= timeEmotion) && (stop == "false")){

        $('#startEmozioni').html("Start emozioni...");

        
        console.log("sono a metà video");
        stop = "true";

        var pathname = window.location.search;
        var session = ""+pathname.split("?session=");
        session = session.substring(1);
        
        var unitId = document.getElementById('clippy_stage').getAttribute("name");
        var unit = document.getElementById('source_video').src;
        unit= unit.split("/");
        unit= unit[unit.length-1];
        unit= unit.split(".");
        unit= unit[0].split("_");
        
        var data = {
            sessione : ""+session,
            unitId : ""+unitId,
            //unit : ""+unit[0],
            unit : "000",
            duration : ""+video.duration-17
        };

        $.ajax({
            type: 'GET',
            url: 'emotion.php',
            data: data,
            success: function(data){
                console.log("success");
                console.log("sto mandando il messaggio di take emotion");
                var msg = "startstoria";
                socket.emit('takenemotionmsg', msg);
            }
        });
    }
}

/**************************************************************************
*  Fotografa il pubblico ogni 2 secondi e manda questa foto alle API Face *
*  Le APi restituiscono un insieme di sette emozioni con le loro intesità *
*  per ogni persona del pubblico                                          *
***************************************************************************/
function takescreenshot(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    console.log("sono in takeScreenshot");

    var data = {
        sessione : ""+session,
        operation : "getEmotion"
    }

    socket.on('takenemotionmsg', function(msg){
        console.log("ricevuto messaggio di takenemotionmsg: " + msg);

        $.ajax({
            type: "GET",
            url: 'emotion.php',
            data: data,
            success: function(data){
                var info = JSON.parse(data);

                console.log(info[0]["time"]);

                if(info[0]['emotionBeforeUnit'] != ""){
                    var node = document.createElement("LI");
                    var text = document.createTextNode("Emozione della unit: "+info[0]["emotionBeforeUnit"]);
                    node.appendChild(text);
                    document.getElementById("info_story").appendChild(node);
                }

                var node = document.createElement("LI");
                var text = document.createTextNode("-------------------------------------------------------------------------------");
                node.appendChild(text);
                document.getElementById("info_story").appendChild(node);

                node = document.createElement("LI");
                text = document.createTextNode("Unit: "+info[0]["unit"]);
                node.appendChild(text);
                document.getElementById("info_story").appendChild(node);

                var dataEmotion = new Array();

                node = document.createElement("LI");
                text = document.createTextNode("Chiamate alle API Face: 5");
                node.appendChild(text);
                document.getElementById("info_story").appendChild(node);

                wait(2000);

                var counter = 0;
                for(var i=0; i<5; i++){

                    /*******************
                    *   Videocamera    *
                    ********************/
                    
                    //fotografia del pubblico
                    var player = document.getElementById('camera');
                    var canvas = document.getElementById('canvas');
                    var context = canvas.getContext('2d');

                    context.drawImage(player, 0, 0, canvas.width, canvas.height);
                    
                    var body1 = canvas.toDataURL();
        
                    //con le immagini
                    /*var img = document.getElementById("img");
                    var canvas = document.getElementById('canvas');
                    var context = canvas.getContext('2d');
                    
                    context.drawImage(img, 0, 0, canvas.width, canvas.height);
    
                    var body = canvas.toDataURL();*/
    
                    console.log("chiamata API");

                    callApi(body1).then(response => {
                        console.log("Response: " + response);
                        dataEmotion = [...dataEmotion ,...response];
                        
                        console.log("counter: "+counter+" i: "+i);
                        if(counter++ == i-1){
                            console.log("emotion: "+dataEmotion+" chiamo stepSuccessivo");
                            calcoloEmozione(dataEmotion,info);
                        }
                    });
    
                    wait(1000);
                }
            }
        });
    });

    socket.on('endvideomsg', function(msg){
        console.log("ricevuto messaggio: " + msg);

        var node = document.createElement("LI");
        var text = document.createTextNode("FINE DELLA STORIA");
        node.appendChild(text);
        document.getElementById("info_story").appendChild(node);

        var timer = document.getElementById("time");

        var data = {
            sessione : ""+session,
            operation : "saveStoria",
            time : ""+timer
        }
    
        $.ajax({
            type: "GET",
            url: 'scriptDB.php',
            data: data,
            success: function(data){
                console.log("Storia salvata");
            }
        });
    });

    socket.on('consolemsg', function(msg){
        console.log(msg);
        var res = msg.split(" ");
        if(res[0] == "pro")
            $('#pro').css({'outline':' rgb(255, 0, 0) solid thick'});
        else
            $('#notpro').css({'outline':' rgb(255, 0, 0) solid thick'});
        if(res[1] == "alta")
            $('#alta').css({'outline':' rgb(255, 0, 0) solid thick'});
        else
            $('#bassa').css({'outline':' rgb(255, 0, 0) solid thick'});
    });
}

//calcolo dei secondi di attesa
function wait(ms){
    var d = new Date();
    var d2 = null;
    do { d2 = new Date(); }
    while(d2-d < ms);
}


async function callApi(body1){

    var dataEmotion = new Array();

    var params = {
        // Request parameters
        "returnFaceId": "false",
        "returnFaceRectangle": "false",
        "returnFaceLandmarks": "false",
        "returnFaceAttributes": "emotion",
    };
    const URL = "https://westeurope.api.cognitive.microsoft.com/face/v1.0/detect?" + $.param(params);
    try {
        var fetchResult = await fetch(URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/octet-stream',
                "Ocp-Apim-Subscription-Key": "5434d9469c65493fa062cb9891461f3c"
            },
            body: makeblob(''+body1)

        });
        var response = await fetchResult;
        var jsonData = await response.json();
        //console.log(jsonData);
        
        for(var j=0; j<jsonData.length; j++){
            
            var score = jsonData[j].faceAttributes.emotion;
            
            for(var e in score) {
                var obj = e+":"+score[e];
                dataEmotion.push(obj);
            }
        }

        //console.log(dataEmotion);
        return dataEmotion;

    } catch(e) {
        throw Error(e);
    }

}

//calcolo emozione più alta
function calcoloEmozione(dataEmotion,info){

    console.log(JSON.parse(JSON.stringify(dataEmotion)));

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    //eliminato neutral
    var emozioni = ["anger", "contempt", "disgust", "fear", "happiness", "sadness", "surprise"];
    var publ_emot = [];
    var saveEmotion = "";
    var sum = 0.0;
    //var soglia = 0.010;
    for(var n=0; n<emozioni.length; n++){
        for(var m=0; m<dataEmotion.length; m++){
            var str = dataEmotion[m].split(":");
            if(emozioni[n] == str[0]){
                sum = parseFloat(""+sum) + parseFloat(""+str[1]);
            }
        }
        publ_emot.push(sum);
        saveEmotion += emozioni[n]+" "+sum+"\n";
        sum = 0.0;
    }

    var id  = publ_emot.indexOf(Math.max.apply(null, publ_emot));
    var emotion = emozioni[id];
    console.log(emotion);

    var data = {
        sessione : ""+session,
        operation : "save",
        emozioni : saveEmotion
    }

    $.ajax({
        type: "GET",
        url: 'scriptDB.php',
        data: data,
        success: function(data){
            console.log("array salvato");
        }
    });
    //console.log(publ_emot);

    var data = {
        unit : ""+info[0]["idunit"],
        sessione : ""+session,
        emozione : ""+emotion
    }

    $.ajax({
        type: "GET",
        url: 'emotion.php',
        data: data,
        success: function(data){
            console.log("sto mandando il messaggio di emozione fatta");
            var msg = emotion;
            socket.emit('emotionmsg', msg);
        }
    });

    var node = document.createElement("LI");
    var text = document.createTextNode("Emozione del pubblico: "+emotion.toUpperCase());
    node.appendChild(text);
    document.getElementById("info_story").appendChild(node);

    $("#emotion").html("Emozione del pubblico: "+emotion.toUpperCase());
    $('#pro').css({'outline':' none'});
    $('#notpro').css({'outline':' none'});
    $('#alta').css({'outline':' none'});
    $('#bassa').css({'outline':' none'});
}


//parsifico l'url della fotografia
function makeblob (dataURL) {
    var BASE64_MARKER = ';base64,';
    if (dataURL.indexOf(BASE64_MARKER) == -1) {
        var parts = dataURL.split(',');
        var contentType = parts[0].split(':')[1];
        var raw = decodeURIComponent(parts[1]);
        return new Blob([raw], { type: contentType });
    }
    var parts = dataURL.split(BASE64_MARKER);
    var contentType = parts[0].split(':')[1];
    var raw = window.atob(parts[1]);
    var rawLength = raw.length;

    var uInt8Array = new Uint8Array(rawLength);

    for (var i = 0; i < rawLength; ++i) {
        uInt8Array[i] = raw.charCodeAt(i);
    }

    return new Blob([uInt8Array], { type: contentType });
}

//bottone per il restart della storia
$("#btn-restart").click(function(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    var data = {
        operation : "restart"
    };    

    $.ajax({
        type: "GET",
        url: 'scriptDB.php',
        data: data,
        success: function(data){

            console.log("sto mandando il messaggio di restart storia");
            var msg = "restart";
            socket.emit('restartmsg', msg);

            clearTimeout(timerID);
            var node = document.createElement("LI");
            var text = document.createTextNode("Restart della storia");
            node.appendChild(text);
            document.getElementById("info_story").appendChild(node);
        }
    });
});

/******************************************************************
* Cronometro della storia                                         *
* Viene chiamato quando viene fatta partire la prima unit         *
******************************************************************/

var startTime = 0;
var start = 0;
var end = 0;
var diff = 0;
var timerID = 0;

function time() {

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);
    
    var data = {
        sessione : ""+session,
        operation : "start"
    };

    socket.on('startmsg', function(msg){
        console.log("ricevuto messaggio: " + msg);
        if(msg == "startstoria"){
            console.log("devo iniziare la storia");
    
            $.ajax({
                type: 'GET',
                url: 'scriptDB.php',
                data: data,
                success: function(data){
                    var obj = JSON.parse(data);
                    if(obj[0]['start'] == "start"){
                        start = new Date();
                        chrono();
                    }
                }
            });
        }
    });

    socket.on('endstorymsg', function(msg){
        console.log("ricevuto messaggio: " + msg);
        console.log("fine della storia, stoppo il timer");

        $.ajax({
            type: 'GET',
            url: 'scriptDB.php',
            data: data,
            success: function(data){
                clearTimeout(timerID);
            }
        });
    });
}

//aumenta il cronometro
function chrono(){
	end = new Date();
	diff = end - start;
	diff = new Date(diff);
	var sec = diff.getSeconds();
	var min = diff.getMinutes();
	var hr = diff.getHours()-1;
	if (min < 10){
		min = "0" + min;
	}
	if (sec < 10){
		sec = "0" + sec;
	}
	document.getElementById("time").innerHTML = "Time: "+hr+":"+min+":"+sec;
	timerID = setTimeout("chrono()", 10);
}

