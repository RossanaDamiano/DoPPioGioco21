<?php

    /********************************************************
     *         GESTIONE GENERALE DELLA PIATTAFORMA          *
     ********************************************************/

    $host = "db";
    $username = "root";
    $password = "root";
    $db = "my_labinterdisciplinare1516";

    //connessione al DB
    if (!($conn = mysqli_connect($host, $username, $password)))
        die("Connessione fallita!");

    if (!(mysqli_select_db($conn, $db)))
        die("Data base non trovato!");

    $resultArray = array();

    /********************************************************
     *             (1)GESTIONE DELLA SESSIONE               *
     ********************************************************/
    if(isset($_GET['operation']) && $_GET['operation'] == "session" && isset($_GET['utente'])){
        
        $utente = $_GET['utente'];

        //controllo se è già stato fatto un accesso con l'utente 'labint1819'
        $query="SELECT * FROM `session` WHERE `utente` = '$utente' && `page` = 0";
        $result = mysqli_query($conn, $query);
        if ($result && mysqli_num_rows($result) == 0){

            $sessione = date("Y-m-d H:i:s");

            $query="INSERT INTO `session` (`timestamp`,`utente`,`page`) VALUES ('$sessione', '$utente', 0)";
            if (!($result = mysqli_query($conn, $query)))
                die("Non riesco a creare la sessione");

            $sql = "TRUNCATE TABLE `unit_story_update`";
            if (!($result = mysqli_query($conn, $sql)))
                die("Non riesco a svutare la tabella");
            
            $sql = "TRUNCATE TABLE `take_emotion_publ`";
            if (!($result = mysqli_query($conn, $sql)))
                die("Non riesco a svutare la tabella");

            $handle = fopen('valutazionePubl.txt', 'w');
            fclose($handle);

            $query="SELECT * FROM `session`  WHERE `timestamp` = '$sessione' && `utente` = '$utente' && `page` = 0";
            if (!($result = mysqli_query($conn, $query)))
                die("Non trovo la sessione");

            $riga = mysqli_fetch_array($result, MYSQLI_ASSOC);
            $id = $riga["idsession"];

            $resultArray[]=array("sessione" => $riga["idsession"],
                                "timestamp" => $riga["timestamp"]);

            $sql = "INSERT INTO `session_unit` (`id_session`,`update_unit`, `page_update`) VALUES ('$id', 0, 0)";
            if (!($result = mysqli_query($conn, $sql)))
                die("Non riesco a salvare la sessione");
        }
        else{
            $riga = mysqli_fetch_array($result, MYSQLI_ASSOC);
            $id = $riga["idsession"];

            $resultArray[]=array("sessione" => $riga["idsession"],
                                "timestamp" => $riga["timestamp"]);

            $handle = fopen('valutazionePubl.txt', 'w');
            fclose($handle);
        }
    }

    /********************************************************
     * La pagina console parte e rende utilizzabili         *
     * tutte le altre pagine...                             *
     ********************************************************/
    if(isset($_GET['operation']) && $_GET['operation'] == "startSession" && isset($_GET['utente']) && isset($_GET["sessione"])){
        $utente = $_GET['utente'];
        $sessione = $_GET['sessione'];
        
        $sql = "UPDATE `session` SET `page` = 1 WHERE idsession = '$sessione' && utente = '$utente'";
        if (!($result = mysqli_query($conn, $sql)))
            die("errore aggiornamento");
    }

    /********************************************************
     * ...tutte le altre pagine recuperano lo stesso numero *
     * di sessione                                          *
     ********************************************************/
    if(isset($_GET['operation']) && $_GET['operation'] == "getSession" && isset($_GET['utente']) && isset($_GET['timestamp'])){
        $utente = $_GET['utente'];
        $timestamp = $_GET['timestamp'];

        $query="SELECT * FROM `session` WHERE `timestamp` = '$timestamp' && `utente` = '$utente'";
            
        if (!($result = mysqli_query($conn, $query)))
            die("errore query");
        
        $riga = mysqli_fetch_array($result, MYSQLI_ASSOC);

        //controllo che la pagina console ci sia entrata
        if ($result && $riga['page'] == 1){
            $resultArray[]=array("sessione" => $riga["idsession"]);
        }
        else{
            die("errore nella setSession");
        }
    }

    /********************************************************
     *         (2)CARICAMENTO DELLE UNIT INIZIALI           *
     ********************************************************/
    if(isset($_GET['operation']) && $_GET['operation'] == "listaClipt"){

        $query="SELECT `title`, `idunit` FROM `unit` WHERE `initial` = '1' AND `in_use` = 1 ORDER BY `title`;";
        
        if (!($result = mysqli_query($conn, $query)))
            die("Non trovo la lista delle clip");
        
        while($unit = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $resultArray[]=array("candidata" => $unit["idunit"],
                                 "nome" => stripslashes($unit["title"]));
        }

        $sql = "TRUNCATE TABLE `take_emotion_publ`";
        if (!($result = mysqli_query($conn, $sql)))
            die("Non riesco a svutare la tabella");
        
    }

    /********************************************************
     *              (3)CARICAMENTO CLIPT                    *
     ********************************************************/
    if(isset($_GET['session']) && isset($_GET['unitStart'])){
        $sessione = $_GET['session'];
        $unitStart = $_GET["unitStart"];
        $array_emotions_inverse = array(1 => "amusement", 2 => "pride", 3 => "joy", 4 => "relief", 5 => "interest", 6 => "pleasure", 7 => "hot anger", 8 => "panic fear", 9 => "despair", 10 => "irritation", 11 => "anxiety", 12 => "sadness");
            
        $sql = "SELECT * FROM `unit` WHERE `idunit` = '$unitStart' ";
        $title = "";
        $emotionUnit = "";
        if (!($result = mysqli_query($conn, $sql)))
            die("Non trovo l'ultima unit inserita");
        while($unit = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $title = $unit["title"];
            if($unit["id_emotion"] != "")
                $emotionUnit = $array_emotions_inverse[$unit["id_emotion"]];
        }

        $sql = "INSERT INTO unit_story_update (id_unit,unit_title,emotion_publ,emotion_unit) VALUES ('$unitStart', '$title', 'start', '$emozioneUnit')";
        if (!($result = mysqli_query($conn, $sql)))
            die("errore aggiornamento");
        
        $sql = "INSERT INTO logStory (sessione,id_unit,unit_title,emotion_publ,emotion_unit) VALUES ('$sessione','$unitStart','$title', '', '$emozioneUnit')";
        if (!($result = mysqli_query($conn, $sql)))
            die("errore aggiornamento");
    }

    /********************************************************
     *                  Start del timer                     *
     ********************************************************/
    if(isset($_GET['operation']) && isset($_GET['sessione']) && $_GET['operation'] == "start"){
        
        $session = $_GET['sessione'];

        //prendo la query con ID più alto
        $query = "SELECT * FROM unit_story_update ORDER BY id DESC LIMIT 1";

        if (!($result = mysqli_query($conn, $query)))
            die("errore query");
        $riga = mysqli_fetch_array($result, MYSQLI_ASSOC);
        
        // controlla se ci sono nuove righe
        if ($riga["emotion_publ"] == "start") {
            $resultArray[]=array("start" => "start");
        }
        else{
            die("start del timer errato");
        }
    }

    /********************************************************
     *               (4)RECUPERO CONTATORE                  *
     ********************************************************/
    if(isset($_GET['clipt']) && isset($_GET['contatore'])){
        $clipt = $_GET['clipt'];

        $sql = "SELECT * FROM `unit_story_update` WHERE id_unit = $clipt";
        if (!($result = mysqli_query($conn, $sql)))
          	 die("Non trovo le emozioni della clip");
        while($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $resultArray[]=array("count" => $riga['id']);
        }
    }

    /********************************************************
     *             (5)RECUPERO PROSSIMA UNIT                *
     ********************************************************/
    if(isset($_GET['unit']) && isset($_GET['response']) && 
        isset($_GET['sessione']) && isset($_GET['decisione']) &&
            isset($_GET['intensity']) && isset($_GET['contatore']) && isset($_GET['emozione'])){

        $unit = $_GET["unit"];
        $response = $_GET["response"];
        $sessione = $_GET["sessione"];
        $decisione = $_GET["decisione"];
        $intensity = $_GET["intensity"];
        $contatore = $_GET["contatore"];
        $emotion = $_GET["emozione"];
        
        $sql = "SELECT * FROM take_emotion_publ WHERE id_unit = '$unit'";
        if (!($result = mysqli_query($conn, $sql)))
               die("Non trovo le emozioni della clip");
        $cont = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $response = $cont["emotion"];

        /*GRUPPI:          MICROSOFT

        POS HIGH
        Amusement          Happiness
        Pride        =>    Surprise
        Joy

        POS LOW
        Relief
        Interest     =>    Neutral
        Pleasure

        NEG HIGH
        Hot anger          Anger
        Panic fear   =>    Disgust
        Despair            Fear

        NEG LOW
        Irritation         Contempt
        Anxiety      =>    Sadness
        Sadness            

        NUOVE REGOLE:

        GIOCA A FAVORE: STESSA POLARITà
        GIOCA CONTRO: POLARITà INVERSA

        */
        
        /* vecchio array */
        $array_emotions_old = array("amusement" => 1, "pride" => 2, "joy" => 3, "relief" => 4, "interest" => 5, "pleasure" => 6, "hot anger" => 7, "panic fear" => 8, "despair" => 9,  "irritation" => 10, "anxiety" => 11, "sadness" => 12);

        $array_emotions = array("happiness" => 1, "surprise" => 2, "neutral" => 3, "anger" => 4, "disgust" => 5, "fear" => 6, "contempt" => 7, "sadness" => 8);

        $array_emotions_inverse = array(1 => "amusement", 2 => "pride", 3 => "joy", 4 => "relief", 5 => "interest", 6 => "pleasure", 7 => "hot anger", 8 => "panic fear", 9 => "despair", 10 => "irritation", 11 => "anxiety", 12 => "sadness");
         /* vecchio array */
        $emo_groups_old = array(1 => "ph", 2 => "ph", 3 => "ph", 4 => "pl", 5 => "pl", 6 => "pl", 7 => "nh", 8 => "nh", 9 => "nh", 10 => "nl", 11 => "nl", 12 => "nl");
        
        $emo_groups = array(1 => "ph", 2 => "ph", 3 => "pl", 4 => "nh", 5 => "nh", 6 => "nh", 7 => "nl", 8 => "nl");

        $sql_base = "SELECT * FROM (`story_graph` JOIN `unit` ON `unit_idunit-after` = `idunit` ) JOIN `unit_has_emotion` ON `unit_has_emotion`.`id_unit` = `unit`.`idunit` WHERE `in_use` = 1 AND `unit_idunit-before` = '$unit' ";

        $emo_number = "";
        $gruppo_response = "";

        if(array_key_exists($response, $array_emotions)){
            $emo_number = $array_emotions[$response];
            $gruppo_response = $emo_groups[$emo_number];
        }
        else{
            $emo_number = $array_emotions_old[$response];
            $gruppo_response = $emo_groups_old[$emo_number];
        }
        
        switch ($gruppo_response){
            case "ph":
                if ($decisione == "pro") {
                    if ($intensity == "alta") {$sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3)";}
                        else {$sql = $sql_base . "AND (`id_emotion` = 4 OR `id_emotion` = 5 OR `id_emotion` = 6)";}
                    } else {
                    //contro!
                    if ($intensity == "alta")	{$sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9)";}
                        else {$sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12)";}
                    }
                break;
            case "pl":
                if ($decisione == "pro") {
                    if ($intensity == "alta"){
                        $sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3)";
                    }else {
                        $sql = $sql_base . "AND (`id_emotion` = 4 OR `id_emotion` = 5 OR `id_emotion` = 6)";
                    }
                } else {
                //contro!
                    if ($intensity == "alta"){
                        $sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9)";
                    }else {
                        $sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12)";
                    }
                }
                break;
            case "nh":
                if ($decisione == "pro") {
                    if ($intensity == "alta") {
                        $sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9)";
                    }
                    else {
                        $sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12)";
                    }
                } else {
                    //contro!
                    if ($intensity == "alta"){
                        $sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3)";
                    }else {
                        $sql = $sql_base . "AND (`id_emotion` = 4 OR `id_emotion` = 5 OR `id_emotion` = 6)";
                    }
                }
                break;
            case "nl":
                if ($decisione == "pro") {
                    if ($intensity == "alta") {
                        $sql = $sql_base . "AND (`id_emotion` = 7 OR `id_emotion` = 8 OR `id_emotion` = 9)";
                    }else {
                        $sql = $sql_base . "AND (`id_emotion` = 10 OR `id_emotion` = 11 OR `id_emotion` = 12)";
                    }
                } else {
                    //contro!
                    if ($intensity == "alta"){
                        $sql = $sql_base . "AND (`id_emotion` = 1 OR `id_emotion` = 2 OR `id_emotion` = 3)";
                    }else {
                        $sql = $sql_base . "AND (`id_emotion` = 4 OR `id_emotion` = 5 OR `id_emotion` = 6)";
                    }
                }
                break;
        }
        if (!($result = mysqli_query($conn, $sql)))
            die	("Non trovo le continuazioni");

        $num_rows = mysqli_num_rows($result);
        
        $num_rows_max = $num_rows-1;

        // 17-18: seleziono quella che ha esattamente stessa emozione, solo se non c'è ricorro al random

        $num_extract = rand(0,$num_rows_max);

        //17-18

        $i = 0;
        $found = false;
        while($unit = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $resultArray[]=array("title" => $unit["title"],
                                "idunit" => $unit["idunit"],
                                "idemotion" => $unit["id_emotion"],
                                "emotionUnit" => $array_emotions_inverse[$unit["id_emotion"]],
                                "image" => $unit["URI"],
                                "emotion" => $emotion,
                                "final" => $unit["final"]);

            if ($unit["id_emotion"] == $emo_number){
                $found = true;
                break;
            } else {
            $i++;
            }
        }

        //vecchio codice

        if ($found == false){

            mysqli_data_seek($result, 0);

            $i = 0;
            while($unit = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                if ($i==$num_extract) {
                    $resultArray[]=array("title" => $unit["title"],
                                "idunit" => $unit["idunit"],
                                "idemotion" => $unit["id_emotion"],
                                "emotionUnit" => $array_emotions_inverse[$unit["id_emotion"]],
                                "image" => $unit["URI"],
                                "emotion" => $emotion,
                                "final" => $unit["final"]);
                }
                $i++;
            }
        }
    }

    /**************************************************************
     *  (6)AUMENTO CONTATORE UNIT (aggiungo emozione della unit)  *
     **************************************************************/
    if(isset($_GET['sessione']) && isset($_GET['unit']) && isset($_GET['title']) && isset($_GET['emozioneUnit'])){
        $sessione = $_GET['sessione'];
        $idunit = $_GET['unit'];
        $title = $_GET['title'];
        $emozioneUnit = $_GET['emozioneUnit'];

        $sql = "INSERT INTO unit_story_update (id_unit,unit_title,emotion_publ,emotion_unit) VALUES ('$idunit', '$title', '', '$emozioneUnit')";
        if (!($result = mysqli_query($conn, $sql)))
            die("errore aggiornamento");
        
        $sql = "INSERT INTO logStory (sessione,id_unit,unit_title,emotion_publ,emotion_unit) VALUES ($sessione,'$idunit','$title', '', '$emozioneUnit')";
        if (!($result = mysqli_query($conn, $sql)))
            die("errore aggiornamento");
    }

    /********************************************************
     *              (7)RESTART DELLA STORIA                 *
     ********************************************************/
    if(isset($_GET['sessione']) && isset($_GET['operation']) && $_GET["operation"] == "restart"){

        $sessione = $_GET['sessione'];

        $sql = "INSERT INTO unit_story_update (id_unit,unit_title,emotion_publ,emotion_unit) VALUES ('', '', 'restart','')";
        if (!($result = mysqli_query($conn, $sql)))
            die("errore aggiornamento");
        
        $sql = "INSERT INTO logStory (sessione,id_unit,unit_title,emotion_publ,emotion_unit) VALUES ($sessione,'', '', 'restart','')";
        if (!($result = mysqli_query($conn, $sql)))
            die("errore aggiornamento");
        
        $sql = "TRUNCATE TABLE `take_emotion_publ`";
        if (!($result = mysqli_query($conn, $sql)))
            die("Non riesco a svutare la tabella");  
            
    }

    /********************************************************
     *               Restart della console                  *
     ********************************************************/
    if(isset($_GET['operation'])  && isset($_GET['sessione']) && $_GET['operunit_story_updateation'] == "restart"){
        
        $session = $_GET['sessione'];

        //prendo la query con ID più alto
        $query = "SELECT * FROM unit_story_update ORDER BY id DESC LIMIT 1";

        if (!($result = mysqli_query($conn, $query)))
            die("errore query");
        $riga = mysqli_fetch_array($result, MYSQLI_ASSOC);
        
        // controlla se ci sono nuove righe
        if ($riga["emotion_publ"] == "restart") {
            $resultArray[]=array("restart" => "restart");
        }
        else{
            die("non ho trovato la riga sul db: unit_story_update");
        }
    }

    /********************************************************
     *  Scrivo in un file l'array di emozioni del pubblico  *
     ********************************************************/
    if(isset($_GET['sessione']) && isset($_GET['operation']) && isset($_GET['emozioni']) && $_GET['operation'] == "save"){
        
        $sessione = $_GET['sessione'];
        $emotion = $_GET['emozioni'];
        $myfile = fopen("valutazionePubl.txt", "a") or die("Unable to open file!");
        fwrite($myfile, $emotion);
        fclose($myfile);

    }

    /********************************************************
     *  Leggo dal file l'array delle emozioni del pubblico  *
     ********************************************************/
    if(isset($_GET['operation']) && $_GET['operation'] == "read"){

        $myFile = "valutazionePubl.txt";
        $fh = fopen($myFile, 'r') or die("Unable to read file!");
        $theData = fread($fh, filesize($myFile));
        $my_array = explode("\n", $theData);
        
        foreach($my_array as $line){
            $tmp = explode(" ", $line);
            $resultArray[]=array($tmp[0]."" => $tmp[1]);
        }
        fclose($fh);
    }

    //chiusura connessione al DB
    $conn = NULL;
        
    echo json_encode($resultArray);

?>

