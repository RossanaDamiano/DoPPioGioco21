<?php

	/********************************************************
     *      GESTIONE DELL'EMOZIONE DEL PUBBLICO             *
     ********************************************************/

	$host = "db";
	$username = "root";
	$password = "root";
	$db = "my_labinterdisciplinare1516";

	//connessione al DB
	if (!($conn = mysqli_connect($host, $username, $password)))
		die("Connessione fallita!");

	if (!(mysqli_select_db($conn, $db)))
		die("Data base non trovato!");

	$resultArray = array();

	/********************************************************
     * Aggiungo una riga nella tabella delle emozioni       *
	 * del pubblico                                         *
     ********************************************************/
    if(isset($_GET["sessione"]) && isset($_GET["unitId"]) && isset($_GET["unit"]) && isset($_GET["duration"])){
		$sessione = $_GET["sessione"];
		$unitId = $_GET["unitId"];
		$unit = $_GET["unit"];
		$duration = $_GET["duration"];

		$sql = "INSERT INTO take_emotion_publ (id_unit,title,time_video,emotion,camera) VALUES ('$unitId', '$unit', $duration, '', 'true')";
		if (!($result = mysqli_query($conn, $sql)))
			die("errore aggiornamento");
	}

	/********************************************************
     * Gestione del video, coordina la durata               *
	 * del video con la cattura delle emozioni del pubblico *
     ********************************************************/
	if(isset($_GET["sessione"]) && isset($_GET["operation"]) && ($_GET["operation"] == "getEmotion")){
		
		$query = "SELECT * FROM take_emotion_publ ORDER BY id DESC LIMIT 1";
			
		if (!($result = mysqli_query($conn, $query)))
			die("errore query");
		
		$riga = mysqli_fetch_array($result, MYSQLI_ASSOC);

		if ($result && $riga["camera"] == "true") {

			$query = "SELECT * FROM unit_story_update ORDER BY id DESC LIMIT 1";

			if (!($result = mysqli_query($conn, $query)))
				die("errore query");
			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
				
			$resultArray[]=array("idunit" => $riga['id_unit'],
								"unit" => $riga['title'],
								"time" => $riga['time_video'],
								"emotionBeforeUnit" => $row['emotion_unit']);
			
			$title = $riga['title'];

			$sql = "UPDATE take_emotion_publ SET camera = 'false' WHERE title = '$title'";
			if (!($result = mysqli_query($conn, $sql)))
				die("errore aggiornamento");

		}
		else{
			die("riga non trovata take_emotion_publ");
		}
	}

	/********************************************************
     *     Aggiorno l'emozione del pubblico nel database    *   
     ********************************************************/
	if(isset($_GET["unit"]) && isset($_GET["sessione"]) && isset($_GET["emozione"])){
		$sessione = $_GET["sessione"];
		$unit = $_GET["unit"];
		$emotion = $_GET["emozione"];

		$sql = "UPDATE take_emotion_publ SET emotion = '$emotion' WHERE id_unit = '$unit'";
		if (!($result = mysqli_query($conn, $sql)))
			die("errore aggiornamento");
		
		$query = "UPDATE unit_story_update SET emotion_publ = '$emotion' WHERE id_unit = '$unit'";
		if (!($result = mysqli_query($conn, $query)))
			die("errore aggiornamento database");
		
		$query = "UPDATE logStory SET emotion_publ = '$emotion' WHERE id_unit = '$unit'";
		if (!($result = mysqli_query($conn, $query)))
			die("errore aggiornamento database");
		
	}

	/********************************************************
     * Cattura dell'emozione del pubblico                   *
	 * Viene restituita alla console e alla pagina emozione *   
     ********************************************************/
	if(isset($_GET["aggiungi"]) && isset($_GET["sessione"])){
		$sessione = $_GET["sessione"];
		$aggiungi = $_GET["aggiungi"];

		$sql = "SELECT * FROM take_emotion_publ WHERE id_unit = '$aggiungi'";
		if (!($result = mysqli_query($conn, $sql)))
			die("errore aggiornamento");
		
		$riga = mysqli_fetch_array($result, MYSQLI_ASSOC);
		
		$emozione = $riga["emotion"];
		$resultArray[]=array("emotion" => $emozione);

	}

	/********************************************************
     *     Recupero il colore dell'emozione del pubblico    *   
     ********************************************************/
	if(isset($_GET["emotion"]) && isset($_GET["operation"]) && $_GET["operation"] == "getColor"){
		$emotion = $_GET["emotion"];

		$sql = "SELECT color FROM emotion_color WHERE emotion = '$emotion'";
		if (!($result = mysqli_query($conn, $sql)))
			die("errore aggiornamento");

		$riga = mysqli_fetch_array($result, MYSQLI_ASSOC);
		$resultArray[]=array("color" => $riga['color']);

	}

	//chiusura connessione al DB
	$conn = NULL;

	echo json_encode($resultArray);
?>
