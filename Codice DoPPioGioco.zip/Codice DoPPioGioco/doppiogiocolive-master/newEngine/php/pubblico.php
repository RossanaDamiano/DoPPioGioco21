<?php
	/********************************************************
     *      GESTIONE DELL'EMOZIONE DEL PUBBLICO 'FINTO'     *
     ********************************************************/

	//risposta del pubblico
	$host = "db";
	$username = "root";
	$password = "root";
	$db = "my_labinterdisciplinare1516";

	//connessione al DB
	if (!($conn = mysqli_connect($host, $username, $password)))
		die("Connessione fallita!");

	if (!(mysqli_select_db($conn, $db)))
        die("Data base non trovato!");
    
    /*
    ESTRAZIONE EMOZIONI
    */

    //1.1 prendo dal db tutte le persone del pubblico
    $emozioni_pubblico = array();
    $facce_pubblico = array();

    $query_audience = "SELECT * FROM `audience`";
    if (!($result = mysqli_query($conn, $query_audience)))
        die("Non riesco  a leggere i dati del pubblico");
    
    //1.2 per ogni persona, prendo le sue emozioni
	while ($persona = mysqli_fetch_array($result, MYSQLI_ASSOC)){
		$persona_id = $persona["id_audience"];
		//echo $persona_id;

		$query_singolo = "SELECT * FROM (`audience_has_emotion` JOIN `audience` ON `idaudience` = `id_audience`) JOIN emotion ON `emotion` = `idemotion` WHERE `idaudience` = '$persona_id'";
		//echo $query_singolo;

		if (!($result_persona = mysqli_query($conn, $query_singolo)))
		die("Non riesco  a leggere i dati della persona nel pubblico");


	    //1.3 estraggo un'emozione per ogni persona del pubblico
		$numero_emo = mysqli_num_rows($result_persona);
		$estratto = rand(1,$numero_emo);
		$counter = 1;


		while ($emo_persona = mysqli_fetch_array($result_persona, MYSQLI_ASSOC)){
			if ($estratto == $counter){
				$emozione_estratta = $emo_persona["emotion name"];
				$file_emozione = $emo_persona["URI"];
				//print_r ($emo_persona);
				//echo "persona $persona_id: estratto $emozione_estratta - $file_emozione ";
				$facce_pubblico[] = $file_emozione;
				$emozioni_pubblico[] = $emozione_estratta;
			}
			$counter++;
		}
    }
    
    //1.4 prendo le emozioni che hanno frequenza maggiore e ne estraggo una a caso

	$frequenze = array_count_values($emozioni_pubblico);
	asort($frequenze);
	//print_r ($frequenze);
	$frequenze_ordinate = array_reverse($frequenze);
	//print_r ($frequenze_ordinate);

	//echo "($frequenze_ordinate[0])";
	list($key, $my_value) = each($frequenze_ordinate);

	$seconda_lista = array();
    $seconda_lista[] = $key;
    
    //creo una lista con le emozioni che hanno frequenza uguale alla prima (le n con maggiore frequenza)
	foreach ($frequenze_ordinate as $candidato){
		list($key, $value) = each($frequenze_ordinate);

		if ($my_value == $value){
			//echo "$key (frequenza: $value) ";
			$seconda_lista[]=$key;
		}
    }
    
    //estraggo un'emozione a caso tra le n con maggiore frequenza
	$count = count($seconda_lista);
	$count = $count - 1;
	if ($count > 1){
		$finale = rand(0,$count);
		//echo " estraggo da 0 a $count ";
    } else {$finale = 0;}
    
    //echo "<p><h2> Reazione del pubblico: $seconda_lista[$finale] </h2></p>";
	//echo "<br/>";

	foreach ($facce_pubblico as $faccia){
        $resultArray[]=array("img" => $faccia,
                            "emozione" => $seconda_lista[$finale]);
		//echo "<img style=\"max-width:100px; max-height:100px; width:\" src=\"../audience/$faccia\" />";
	}

    //chiusura connessione al DB
    $conn = NULL;

    echo json_encode($resultArray);
?>