<?php

    /************************************************************
     *    GESTIONE INFORMAZIONI RIGUARDANTI LE UNIT             *
     * Le pagine scaricano le informazioni che gli servono per  *
     * aggiornare il proprio contenuto e mostrarlo              *
     ************************************************************/

    $host = "db";
    $username = "root";
    $password = "root";
    $db = "my_labinterdisciplinare1516";

    //connessione al DB
    if (!($conn = mysqli_connect($host, $username, $password)))
        die("Connessione fallita!");

    if (!(mysqli_select_db($conn, $db)))
        die("Data base non trovato!");

    //prendo l'ultima sessione
    $session = $_GET['sessione'];

    //controllo se è stata aggiunta una unit
    $query = "SELECT u.id, u.id_unit, u.unit_title, u.emotion_publ, u.emotion_unit FROM unit_story_update u INNER JOIN session_unit s ON s.update_unit < u.id WHERE s.id_session = $session ORDER BY u.id";
    if (!($result = mysqli_query($conn, $query)))
        die("errore query");
    
    // controlla se ci sono nuove righe
    if ($result && $result -> num_rows) {

        $resultArray = array();

        $lastId = 0;
        while($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) { 
            $idunit = $riga['id_unit'];
            $lastId = $riga['id'];
            $emotion = $riga['emotion_publ'];
            $emotionUnit = $riga['emotion_unit'];
        }

        if($emotion == "fine"){
            $resultArray[]=array("final" => 1);
        }else if($emotion == "restart"){
            $resultArray[]=array("final" => "restart");
        }
        else{
            $sql = "SELECT * FROM `unit` WHERE `idunit` = $idunit";
            if (!($result = mysqli_query($conn, $sql)))
                die("Non trovo l'ultima unit inserita");
            while($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) { 
                $resultArray[]=array("idunit" => $riga['idunit'],
                                    "title" => $riga['title'],
                                    "image" => $riga['URI'],
                                    "note" => $riga['notes'],
                                    "final" => 0,
                                    "emotion_publ" => $emotion,
                                    "emotion_unit" => $emotionUnit);
            }
        }

        $query = "UPDATE `session_unit` SET page_update = (page_update +1) WHERE id_session = $session";
        if (!($result = mysqli_query($conn, $query)))
            die("errore aggiornamento database");

        $query = "SELECT page_update FROM session_unit WHERE id_session=$session";
        if (!($res = mysqli_query($conn, $query)))
            die("errore query");
        $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
        $page = $row['page_update'];
        
        //aggiornamento tabella session_unit quando tutte le pagine si sono sincronizzate
        if($page == 3){
            $query = "UPDATE session_unit SET update_unit = $lastId, page_update = 0 WHERE id_session = $session";
            if (!($result = mysqli_query($conn, $query)))
                die("errore aggiornamento database");
        }

        //chiusura connessione al DB
        $conn = NULL;

        echo json_encode($resultArray);

    } else {

        //chiusura connessione al DB
        $conn = NULL;
        die("errore query: non ci sono nuove unit");
    }


?>