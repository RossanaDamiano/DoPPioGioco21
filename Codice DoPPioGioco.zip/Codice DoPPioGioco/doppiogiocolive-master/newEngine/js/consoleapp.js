/*******************************************
* Gestione della pagina della console      *
********************************************/

$('#fine').hide();
$("#startStory").hide();
$("#cliptitle_stage").hide();
$('#pubblico').hide();

const socket = io('http://localhost:14080');
socket.on('connect', function(){
    console.log("Connessione stabilita globale");
});

//passo il numero di sessione alle altre pagine
//caricamento della pagina --> carico le clip iniziali
$(document).ready(function(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    var data={
        operation : "startSession",
        utente : "labint1819",
        sessione : ""+session
    };

    $.ajax({
        type: "GET",
        url: 'php/scriptDB.php',
        data: data,
        success: function(data){
            
            console.log("sto mandando il messaggio di sessione creata");
            var msg = emotion;
            socket.emit('startsessionmsg', msg);

            var output = '';

            var data={
                operation : "listaClipt"
            };

            $.ajax({
                type: "GET",
                url: 'php/scriptDB.php',
                data: data,
                success: function(data){
                    var info = JSON.parse(data);
                    for(var i=0; i<info.length; i++){
                        var row = info[i];
                        output +='<option value=\"'+row["candidata"]+'\">'+row["nome"]+'</option>';
                    }
                    $("#scelta").html(output);
                }
            }); 
        }
    });
});

//scelta la clip --> comincia la storia
$("#btn-start").click(function(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);
    
    $("#startConsole").hide();
    $("#startStory").show();
    $('#pubblico').show();
    
    var data = {
        session : ""+session,
        unitStart : ""+$("#scelta").val()
    }

    $.ajax({
        type: "GET",
        url: 'php/scriptDB.php',
        data: data,
        success: function(data){

            console.log("sto mandando il messaggio di start evento");
            var msg = "startstoria";
            socket.emit('startmsg', msg);

            console.log("li avvio da ajax");
            reazione();
            restart();

        }
    });
});

//si mette in attesa di sapere la reazione del pubblico
function reazione(){
    console.log("function reazione");
    
    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    var outEmo = "";
        
    console.log("aspetto....");
    socket.on('emotionmsg', function(msg){
        console.log("ricevuto messaggio di emozione: " + msg);
        console.log("ho ricevuto l'emozione del pubblico ...");

        outEmo = "<p><h1 id=\"emozione_pubblico\" value=\""+msg+"\"> Reazione del pubblico: "+msg.toUpperCase()+" </h1></p>";
        $('#emotion').html(outEmo);
    });
} 

//scelta del performer su come comtinuare la storia in base alla reazione del pubblico
$("#btn-nextGo").click(function(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    var aggiungi = ""+$("#scelta").val();
    var decisione = "";
    var intensity = "";
    var emotion = ""+$("#emozione_pubblico").attr('value');

    var pleasant = document.getElementById("pleasant");

    //controllo se i bottoni hanno il bordo rosso oppure no
    //se rosso --> è stato selezionato
    //se none --> altrimenti
    if(pleasant.getAttribute('style') == "outline: none;"){
        decisione = "notpro";
    }
    else{
        decisione = "pro";
    }

    var high = document.getElementById("high");
    if(high.getAttribute('style') == "outline: none;"){
        intensity = "bassa";
    }
    else{
        intensity = "alta";
    }

    var data = {
        clipt : ""+aggiungi,
        contatore : ""
    }

    $.ajax({
        type: "GET",
        url: 'php/scriptDB.php',
        data: data,
        success: function(data){
            var count = JSON.parse(data);

            var data2 = {
                unit : aggiungi,
                response : "",
                sessione : ""+session,
                decisione : ""+decisione,
                intensity : ""+intensity,
                contatore : ""+count[0]['count'],
                emozione : ""+emotion
            }
            
            //calcolo della prossima unit da caricare
            $.ajax({
                type: "GET",
                url: 'php/scriptDB.php',
                data: data2,
                success: function(data){
                    var newunit = JSON.parse(data);

                    console.log(data);

                    //fine della storia
                    if(newunit[0]['final'] == 1){

                        var data3 = {
                            sessione : ""+session,
                            unit : ""+newunit[0]["idunit"],
                            title : ""+newunit[0]["title"],
                            emozioneUnit : ""+newunit[0]["emotionUnit"]
                        };

                        $.ajax({
                            type: "GET",
                            url: 'php/scriptDB.php',
                            data: data3,
                            success: function(data){

                                console.log(newunit[0]["idunit"]);

                                var msg = "finestoria";
                                socket.emit('endstorymsg', msg);
                                console.log("comunico che è finita la storia");

                                $("#startConsole").show();
                                document.getElementById("pleasant").setAttribute("style", "outline: none;");
                                document.getElementById("high").setAttribute("style", "outline: none;");
                                document.getElementById("opponent").setAttribute("style", "outline: none;");
                                document.getElementById("low").setAttribute("style", "outline: none;");
                                $("#startStory").hide();
                                $('#emotion').html("");
                                $('#fine').show();
                            }
                        });
                    }
                    else{
                        //caricamento della unit trovata
                        $('#scelta option').attr('value', ''+newunit[0]["idunit"]);
                        
                        var data4 = {
                            sessione : ""+session,
                            unit : ""+newunit[0]["idunit"],
                            title : ""+newunit[0]["title"],
                            emozioneUnit : ""+newunit[0]["emotionUnit"]
                        };

                        $.ajax({
                            type: "GET",
                            url: 'php/scriptDB.php',
                            data: data4,
                            success: function(data){

                                var msg = decisione+""+intensity;
                                socket.emit('updatemsg', msg);
                                console.log("sto mandando le info per la prossima unit");

                                document.getElementById("pleasant").setAttribute("style", "outline: none;");
                                document.getElementById("high").setAttribute("style", "outline: none;");
                                document.getElementById("opponent").setAttribute("style", "outline: none;");
                                document.getElementById("low").setAttribute("style", "outline: none;");
                                $("#emotion").html("");
                            }
                        });
                    }
                }
            });
        }
    });
});

//restart della console
function restart(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);
    
    var data = {
        sessione : ""+session,
        operation : "restart"
    };

    socket.on('restartmsg', function(msg){
        console.log("ricevuto messaggio di restart: " + msg);
        
        $.ajax({
            type: 'GET',
            url: 'php/scriptDB.php',
            data: data,
            success: function(data){
                var obj = JSON.parse(data);
                if(obj[0]['restart'] == "restart"){
                    $("#startConsole").show();
                    document.getElementById("pleasant").setAttribute("style", "outline: none;");
                    document.getElementById("high").setAttribute("style", "outline: none;");
                    document.getElementById("opponent").setAttribute("style", "outline: none;");
                    document.getElementById("low").setAttribute("style", "outline: none;");
                    $("#startStory").hide();
                    $('#emotion').html("");
                }
            }
        });
    });
}