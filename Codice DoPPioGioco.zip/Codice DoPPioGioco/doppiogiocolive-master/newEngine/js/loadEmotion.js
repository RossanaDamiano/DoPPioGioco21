/*******************************************
* Gestione delle emozioni del pubblico     *
********************************************/

function getEmotion(){
    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);
    
    var queryString = {
        sessione : ""+session
    };

    var outEmot = "";
    
    //quando arriva l'emozione la proietto con il colore ad essa associato
    socket.on('emotionmsg', function(msg){
        console.log("ricevuto messaggio di emozione: " + msg);
        console.log("ho ricevuto l'emozione del pubblico ...");

        $.ajax({
            type: 'GET',
            url: 'php/getinfounit.php',
            data: queryString,
            success: function(data){
                console.log(data);
                var unit = JSON.parse(data);
                
                var data = {
                    sessione : ""+session,
                    aggiungi : ""+unit[0]["idunit"]
                };
    
                $.ajax({
                    type: 'GET',
                    url: 'php/emotion.php',
                    data: data,
                    success: function(data){
                        var obj = JSON.parse(data);
                    
                        var color = {
                            emotion : ""+obj[0]['emotion'],
                            operation : "getColor"
                        };

                        $.ajax({
                            type: 'GET',
                            url: 'php/emotion.php',
                            data: color,
                            success: function(data){
                                var c = JSON.parse(data);
                                var ita_emotion = {"anger":"RABBIA","contempt":"DISPREZZO","disgust":"DISGUSTO","fear":"PAURA","happiness":"FELICITÀ",
                                                    "surprise":"SORPRESA","sadness":"TRISTEZZA","hot anger":"RABBIA","irritation":"IRRITAZIONE",
                                                    "panic fear":"PANICO","despair":"DISPERAZIONE","anxiety":"ANGOSCIA","interest":"INTERESSE",
                                                    "relief":"SOLLIEVO","pleasure":"PIACERE","amusement":"DIVERTIMENTO","joy":"FELICITÀ","pride":"ORGOGLIO"};
                                var emozione = ita_emotion[obj[0]['emotion']];
                                if(obj[0]['emotion'] == "fear" || obj[0]['emotion'] == "sadness" || obj[0]['emotion'] == "anxiety" || obj[0]['emotion'] == "panic fear" || obj[0]['emotion'] == "despair"){
                                    outEmot = "<p><h1 style=\"font-size: 1500%; font-family: arial; color: white\">"+emozione+"</h1></p>";
                                    $("#body").css({ 'background-color': ''+c[0]['color'] });
                                }
                                else{
                                    outEmot = "<p><h1 style=\"font-size: 1500%; font-family: arial\">"+emozione+"</h1></p>";
                                    $("#body").css({ 'background-color': ''+c[0]['color'] });
                                }
                                $('#cliptitle_stage').html(outEmot);
                            }
                        });
                    }
                });
            }
        });
    });

    //in attesa della nuova emozione
    socket.on('updatemsg', function(msg){
        console.log("ricevuto messaggio: " + msg);
        $('#cliptitle_stage').html("");
        $("#body").css({ 'background-color': 'white' });
    });

    //in attesa dell'ultima emozione
    socket.on('endstorymsg', function(msg){
        console.log("ricevuto messaggio: " + msg);
        $('#cliptitle_stage').html("");
        $("#body").css({ 'background-color': 'white' });
    });

    //restart della storia
    socket.on('restartmsg', function(msg){
        console.log("ricevuto messaggio: " + msg);

        $.ajax({
            type: 'GET',
            url: 'php/getinfounit.php',
            data: queryString,
            success: function(data){
        
                outEmot = "<p><h1></h1></p>";
                $("#body").css({ 'background-color': 'white' });
                $('#cliptitle_stage').html(outEmot);
                
            }
        });
    });
}

