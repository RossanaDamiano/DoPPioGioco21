/***********************************************************************************
* Vengono prese le immagini dal DB (finto pubblico)                                *
* Non avviene il calcolo per dare un giudizio al pubblico alla fine della sessione *
************************************************************************************/

var stop = "false";

//controllo il tempo del video
function getFrame(){
    stop="false";
    var video = document.getElementById('clippy_stage');
    video.onplay = function (){
        console.log("Durata video: "+video.duration+" start emozioni: "+(video.duration-17));
        video.ontimeupdate = function() {myFunction(video,(video.duration-17))};
    }
    console.log(stop);
}

//a metà video salvo nel DB (tramite emotion.php) le informazioni sul video corrente
//prendo le immagini dal DB e ricavo un'emozione
function myFunction(video, timeEmotion) {
    document.getElementById("demo").innerHTML = video.currentTime;
    if((video.currentTime >= timeEmotion) && (stop == "false")){
        console.log("sono a metà video");
        stop = "true";

        var pathname = window.location.search;
        var session = ""+pathname.split("?session=");
        session = session.substring(1);
        
        var unitId = document.getElementById('clippy_stage').getAttribute("name");
        var unit = document.getElementById('source_video').src;
        unit= unit.split("/");
        unit= unit[unit.length-1];
        unit= unit.split(".");
        unit= unit[0].split("_");
        
        var data = {
            sessione : ""+session,
            unitId : ""+unitId,
            unit : ""+unit[0],
            duration : ""+video.duration-17
        };

        $.ajax({
            type: 'GET',
            url: 'php/emotion.php',
            data: data,
            success: function(data){
                console.log("success");
                console.log("sto mandando il messaggio di take emotion");
                var msg = "startstoria";
                socket.emit('takenemotionmsg', msg);
            }
        });
    }
}

/*************************************************
*  Prendo le immagini e ottengo un'emozione      *
**************************************************/
function takescreenshot(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    console.log("sono in takeScreenshot");

    var data = {
        sessione : ""+session,
        operation : "getEmotion"
    }


    socket.on('takenemotionmsg', function(msg){
        console.log("ricevuto messaggio di takenemotionmsg: " + msg);

        $.ajax({
            type: "GET",
            url: 'php/emotion.php',
            data: data,
            success: function(data){
                var info = JSON.parse(data);

                console.log(info[0]["time"]);

                if(info[0]['emotionBeforeUnit'] != ""){
                    var node = document.createElement("LI");
                    var text = document.createTextNode("Emozione della unit: "+info[0]["emotionBeforeUnit"]);
                    node.appendChild(text);
                    document.getElementById("info_story").appendChild(node);
                }

                var node = document.createElement("LI");
                var text = document.createTextNode("-------------------------------------------------------------------------------");
                node.appendChild(text);
                document.getElementById("info_story").appendChild(node);

                node = document.createElement("LI");
                text = document.createTextNode("Unit: "+info[0]["unit"]);
                node.appendChild(text);
                document.getElementById("info_story").appendChild(node);

                var pubblico = "";
                var emotion = "";

                //chiamata a pubblico.php
                var data = {
                    sessione : ""+session
                }

                $.ajax({
                    type: "GET",
                    url: 'php/pubblico.php',
                    async: false,
                    data: data,
                    success: function(data){
                        var res = JSON.parse(data);
                        emotion = res[0]['emozione'];
                        pubblico += "<p><h2> Reazione del pubblico: "+emotion+" </h2></p><br/>";
                        for(var i=0; i<res.length; i++){
                            pubblico += "<img style=\"max-width:100px; max-height:100px; width:\" src=\"../audience/"+res[i]['img']+"\" />";
                        }
                        $('#img_publ').html(pubblico);
                    }
                });

                console.log(emotion);

                var data = {
                    unit : ""+info[0]["idunit"],
                    sessione : ""+session,
                    emozione : ""+emotion
                }
            
                $.ajax({
                    type: "GET",
                    url: 'php/emotion.php',
                    data: data,
                    success: function(data){
                        console.log("sto mandando il messaggio di emozione fatta");
                        var msg = emotion;
                        socket.emit('emotionmsg', msg);
                    }
                });
                var node = document.createElement("LI");
                var text = document.createTextNode("Emozione del pubblico: "+emotion.toUpperCase());
                node.appendChild(text);
                document.getElementById("info_story").appendChild(node);

            }
        });
    });

    socket.on('endstorymsg', function(msg){
        console.log("ricevuto messaggio: " + msg);

        var node = document.createElement("LI");
        var text = document.createTextNode("FINE DELLA STORIA");
        node.appendChild(text);
        document.getElementById("info_story").appendChild(node);
        
    });
}

//bottone per il restart della storia
$("#btn-restart").click(function(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    var data = {
        restart : "restart"
    };    

    $.ajax({
        type: "GET",
        url: 'php/scriptDB.php',
        data: data,
        success: function(data){

            console.log("sto mandando il messaggio di restart storia");
            var msg = "restart";
            socket.emit('restartmsg', msg);

            clearTimeout(timerID);
            var node = document.createElement("LI");
            var text = document.createTextNode("Restart della storia");
            node.appendChild(text);
            document.getElementById("info_story").appendChild(node);
        }
    });
});

/******************************************************************
* Cronometro della storia                                         *
* Viene chiamato quando viene fatta partire la prima unit         *
******************************************************************/

var startTime = 0;
var start = 0;
var end = 0;
var diff = 0;
var timerID = 0;

function time() {

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);
    
    var data = {
        sessione : ""+session,
        operation : "start"
    };

    socket.on('startmsg', function(msg){
        console.log("ricevuto messaggio: " + msg);
        if(msg == "startstoria"){
            console.log("devo iniziare la storia");
    
            $.ajax({
                type: 'GET',
                url: 'php/scriptDB.php',
                data: data,
                success: function(data){
                    var obj = JSON.parse(data);
                    if(obj[0]['start'] == "start"){
                        start = new Date()
                        chrono();
                    }
                }
            });
        }
    });

    socket.on('endstorymsg', function(msg){
        console.log("ricevuto messaggio: " + msg);
        console.log("fine della storia, stoppo il timer");

        $.ajax({
            type: 'GET',
            url: 'php/scriptDB.php',
            data: data,
            success: function(data){
                clearTimeout(timerID);
            }
        });
    });
}

//aumenta il cronometro
function chrono(){
	end = new Date();
	diff = end - start;
	diff = new Date(diff);
	var sec = diff.getSeconds();
	var min = diff.getMinutes();
	var hr = diff.getHours()-1;
	if (min < 10){
		min = "0" + min;
	}
	if (sec < 10){
		sec = "0" + sec;
	}
	document.getElementById("time").innerHTML = "Time: "+hr+":"+min+":"+sec;
	timerID = setTimeout("chrono()", 10);
}
