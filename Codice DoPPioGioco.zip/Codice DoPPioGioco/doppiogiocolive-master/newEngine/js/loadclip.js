/*******************************************
* Gestione clip e note delle unit          *
********************************************/

$('#clipt').show();
$('#body_premio').hide()

function getContent(){
    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);
    
    var queryString = {
        sessione : ""+session
    };

    var emotionClipt = "";
    var outClipt = "";
    var outNotes = "";

    //carico la unit iniziale della storia
    socket.on('startmsg', function(msg){
        console.log("ricevuto messaggio: " + msg);

        $.ajax({
            type: 'GET',
            url: 'php/getinfounit.php',
            data: queryString,
            success: function(data){
                
                var obj = JSON.parse(data);
            
                if(obj[0]['image'] != "" || obj[0]['image'] != null){
                    outClipt = "<video id=\"clippy_stage\" name=\""+obj[0]['idunit']+"\" position=\"center\" width=\"1200px\" controls autoplay>"+
                                "<source id=\"source_video\" src=\"videoEmozioni.mp4\" type=\"video/mp4\"></video>"+ //video utilizzato per i test
                                "<audio id=\"audio\" position=\"center\" autoplay loop>"+
                                "<source src=\"../audio/intro.mp3\" type=\"audio/mpeg\"></audio>"+
                                "<script type=\"text/javascript\">"+
                                "getFrame();"+
                                "</script>"+
                                "<div style=\"padding-top: 2%\"><h1 id=\"startEmozioni\" style=\"color: white\"></h1></div>";

                                //questa stringa è da mettere al posto del video di utilizzato come test
                                /*"<source id=\"source_video\" src=\"../clips/"+obj[0]['image']+"\" type=\"video/mp4\"></video>"+*/
                }
                
                if(obj[0]['note'] != ""){
                    if(obj[0]['emotion_unit'] != ""){
                        emotionClipt = "<div style=\"float: left; display: block; padding: 2%; text-align: left\"><h1 style=\"color: white\">"+obj[0]['emotion_unit'].toUpperCase()+"</h1></div>";
                    }
                    //timer per il performer
                    var deadline = new Date(Date.parse(new Date()) + 120 * 1000);
                    initializeClock(deadline);
                    outNotes = "<img id=\"clippy_stage\" name=\"clippy_stage\" /><p id=\"notes_mirror\" style=\"line-height: 1\">"+obj[0]['note']+"</p>";
                }
                $('#clip').html(outClipt);
                $('#clipscreen_stage').html(emotionClipt);
                $('#notes_stage').html(outNotes);

            }
        });
    });
    
    //carico le unit successive
    socket.on('updatemsg', function(msg){
        console.log("ricevuto messaggio: " + msg);

        $.ajax({
            type: 'GET',
            url: 'php/getinfounit.php',
            data: queryString,
            success: function(data){

                console.log(data);
                
                var obj = JSON.parse(data);

                var emotions_song = {"amusement" : "positiveHigh.mp3", "pride" : "positiveHigh.mp3", "joy" : "positiveHigh.mp3", "relief" : "positiveLow.mp3", "interest" : "positiveLow.mp3", "pleasure" : "positiveLow.mp3", "hot anger" : "negativeHigh.mp3", "panic fear" : "negativeHigh.mp3", "despair" : "negativeHigh.mp3",  "irritation" : "negativeLow.mp3", "anxiety" : "negativeLow.mp3", "sadness" : "negativeLow.mp3"};
                var audio = emotions_song[obj[0]['emotion_unit']];
                
                if(obj[0]['image'] != "" || obj[0]['image'] != null){
                    outClipt = "<video id=\"clippy_stage\" name=\""+obj[0]['idunit']+"\" position=\"center\" width=\"1200px\" controls autoplay>"+
                                "<source id=\"source_video\" src=\"videoEmozioni.mp4\" type=\"video/mp4\"></video>"+ //video utilizzato per i test
                                "<audio id=\"audio\" position=\"center\" autoplay loop>"+
                                "<source src=\"../audio/"+audio+"\" type=\"audio/mpeg\"></audio>"+
                                "<script type=\"text/javascript\">"+
                                "getFrame();"+
                                "</script>"+
                                "<div style=\"padding-top: 2%\"><h1 id=\"startEmozioni\" style=\"color: white\"></h1></div>";

                                //questa stringa è da mettere al posto del video di utilizzato come test
                                /*"<source id=\"source_video\" src=\"../clips/"+obj[0]['image']+"\" type=\"video/mp4\"></video>"+*/
                }
                
                if(obj[0]['note'] != ""){
                    if(obj[0]['emotion_unit'] != ""){
                        emotionClipt = "<div style=\"padding: 2%; text-align: left\"><h1 style=\"color: white\">"+obj[0]['emotion_unit'].toUpperCase()+"</h1></div>";
                    }
                    //timer per il performer
                    var deadline = new Date(Date.parse(new Date()) + 120 * 1000);
                    initializeClock(deadline);
                    outNotes = "<img id=\"clippy_stage\" name=\"clippy_stage\" /><p id=\"notes_mirror\" style=\"line-height: 1\">"+obj[0]['note']+"</p>";
                }
                $('#clip').html(outClipt);
                $('#clipscreen_stage').html(emotionClipt);
                $('#notes_stage').html(outNotes);

            }
        });
    });

    //carico la unit finale della storia
    socket.on('endstorymsg', function(msg){
        console.log("ricevuto messaggio: " + msg);

        $.ajax({
            type: 'GET',
            url: 'php/getinfounit.php',
            data: queryString,
            success: function(data){
                console.log(data);
                var obj = JSON.parse(data);

                var emotions_song = {"amusement" : "positiveHigh.mp3", "pride" : "positiveHigh.mp3", "joy" : "positiveHigh.mp3", "relief" : "positiveLow.mp3", "interest" : "positiveLow.mp3", "pleasure" : "positiveLow.mp3", "hot anger" : "negativeHigh.mp3", "panic fear" : "negativeHigh.mp3", "despair" : "negativeHigh.mp3",  "irritation" : "negativeLow.mp3", "anxiety" : "negativeLow.mp3", "sadness" : "negativeLow.mp3"};
                var audio = emotions_song[obj[0]['emotion_unit']];
                
                if(obj[0]['image'] != "" || obj[0]['image'] != null){
                    outClipt = "<video id=\"clippy_stage\" name=\""+obj[0]['idunit']+"\" position=\"center\" width=\"1200px\" controls autoplay onended=\"fineStoria()\">"+
                                "<source id=\"source_video\" src=\"videoEmozioni.mp4\" type=\"video/mp4\"></video>"+ //video utilizzato per i test
                                "<audio id=\"audio\" position=\"center\" autoplay loop>"+
                                "<source src=\"../audio/"+audio+"\" type=\"audio/mpeg\"></audio>"+
                                "<script type=\"text/javascript\">"+
                                "getFrame();"+
                                "</script>"+
                                "<div style=\"padding-top: 2%\"><h1 id=\"startEmozioni\" style=\"color: white\"></h1></div>";

                                //questa stringa è da mettere al posto del video di utilizzato come test
                                /*"<source id=\"source_video\" src=\"../clips/"+obj[0]['image']+"\" type=\"video/mp4\"></video>"+*/
                }
                
                if(obj[0]['note'] != ""){
                    if(obj[0]['emotion_unit'] != ""){
                        emotionClipt = "<div style=\"padding: 2%; text-align: left\"><h1 style=\"color: white\">"+obj[0]['emotion_unit'].toUpperCase()+" -> THE END</h1></div>";
                    }
                    //timer per il performer
                    var deadline = new Date(Date.parse(new Date()) + 120 * 1000);
                    initializeClock(deadline);
                    outNotes = "<img id=\"clippy_stage\" name=\"clippy_stage\" /><p id=\"notes_mirror\" style=\"line-height: 1\">"+obj[0]['note']+"</p>";
                }
                $('#clip').html(outClipt);
                $('#clipscreen_stage').html(emotionClipt);
                $('#notes_stage').html(outNotes);
            }
        });
    });

    //restart della storia
    socket.on('restartmsg', function(msg){
        console.log("ricevuto messaggio: " + msg);

        $.ajax({
            type: 'GET',
            url: 'php/getinfounit.php',
            data: queryString,
            success: function(data){
                var obj = JSON.parse(data);
                if(obj[0]['final'] == "restart"){
                    emotionClipt = "";
                    outClipt = "";
                    outNotes = "";
                }
                else{
                    console.log("errore nel restart della storia");
                }
                $('#clip').html(outClipt);
                $('#clipscreen_stage').html(emotionClipt);
                $('#notes_stage').html(outNotes);
            }
        });
    });
}

//finita la storia viene dato un giudizio al pubblico
function fineStoria(){

    var pathname = window.location.search;
    var session = ""+pathname.split("?session=");
    session = session.substring(1);

    var data = {
        operation : "read"
    };

    $.ajax({
        type: 'GET',
        url: 'php/scriptDB.php',
        data: data,
        success: function(data){
            console.log(data);
            var obj = JSON.parse(data);
            var emozioni = ["anger", "contempt", "disgust", "fear", "happiness", "sadness", "surprise","hot anger","irritation",
            "panic fear","despair","anxiety","interest","relief","pleasure","amusement","joy","pride"];
            var sum = 0.0;
            //L = numero delle unit che compongono la storia
            var L = 0;
            //N = numero delle persone del pubblico
            var N = 8;
            for(var n=0; n<emozioni.length; n++){
                for(var m=0; m<obj.length; m++){
                    if(obj[m][""+emozioni[n]] != undefined){
                        if(emozioni[n] == "anger")
                            L += 1;
                        sum = parseFloat(""+sum) + parseFloat(""+obj[m][''+emozioni[n]]);
                    }
                }
            }
            console.log(sum);
            var premio = "";
            if(sum >= 0.0 && sum <= L*N*0.1){
                premio = "<h1 style=\"font-size: 600%\">SCARSI</h1>"
                $('#body_clipt').css({'background-color': '#ea3737'});
            }
            else if(sum >= L*N*0.1 && sum <= L*N*0.3){
                premio = "<h1 style=\"font-size: 600%\">DISCRETI</h1>"
                $('#body_clipt').css({'background-color': '#ffdb00'});
            }
            else{
                premio = "<h1 style=\"font-size: 600%\">FANTASTICI</h1>"
                $('#body_clipt').css({'background-color': '#43971e'});
            }
            
            $('#startEmozioni').hide();
            $('#clipscreen_timer').hide();
            $('#audio').remove();
            $('#clippy_stage').hide();
            $('#premio').html(premio);
            $('#clipt').hide();
            $('#body_premio').show();
   
        }
    });

 }

/**************************************
*       Timer per il performer        *
***************************************/

function getTimeRemaining(endtime) {
    var t = Date.parse(endtime) - Date.parse(new Date());
    var seconds = Math.floor((t / 1000) % 60);
    var minutes = Math.floor((t / 1000 / 60) % 60);
    var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
    var days = Math.floor(t / (1000 * 60 * 60 * 24));
    return {
        'total': t,
        'days': days,
        'hours': hours,
        'minutes': minutes,
        'seconds': seconds
    };
}
  
function initializeClock(endtime) {

    function updateClock() {
        var t = getTimeRemaining(endtime);

        document.getElementById('clipscreen_timer').innerHTML = ""+('0' + t.minutes).slice(-2)+":"+('0' + t.seconds).slice(-2);

        if (t.total <= 0) {
            clearInterval(timeinterval);
        }
    }
  
    updateClock();
    var timeinterval = setInterval(updateClock, 1000);
}