<?php

include '../include/connessione.php';

//$mio_file = $_FILES["photo"];

//echo "ecco il file: $_mio_file[name]";

//print_r ($mio_file);

//$nome = $mio_file["name"];   

//echo $_FILES["photo"]["name"];

//echo "$nome";

//echo "La unit: $unit";

$ok = 0;
//$unit = $_POST["unit"];
//$nomefile = $_FILES["photo"];
//$nomefile = $_FILES["fileToUpload"]["name"];
$target_dir = "../clips/";
$target_file = $target_dir . basename($_FILES["photo"]["name"]);
//echo $target_file;
//$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
	$check = getimagesize($_FILES["photo"]["tmp_name"]);
    //$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        //echo "Il file è ok - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        //echo "File is not an image.";
        $uploadOk = 0;
    }
}

// Check if file already exists
//if (file_exists($target_file)) {
//    echo "Sorry, file already exists.";
//    $uploadOk = 0;
//}

// Check file size (500 kb)

if ($_FILES["photo"]["size"] > 1000000) 
//if ($_FILES["fileToUpload"]["size"] > 2400000) 
{
    //echo "Il file è troppo grande, non deve superare ...";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    //echo "Sorry, your file was not uploaded.";
    
// if everything is ok, try to upload file
} else {

	//Replace image name with timestamp
	$now = date('YmdHis');
	$new_filename =  $now .".". $imageFileType;
	$new_target_file = $target_dir . $new_filename;

	$unit = $_REQUEST["unit"];

    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $new_target_file)) {
        //echo "<div> Il file ". basename( $_FILES["photo"]["name"]). " è stato caricato. ";
        //echo "<p>Torna alla <a href=\"visualizzaUnit.php?unit=$unit\">clip</a> o alla <a href=\"lista_units.php\">lista delle clip</a>.</p></div>";
        $ok = 1;
    } else {
        //echo "Sorry, there was an error uploading your file.";
    }

    //The upload was okay, update info on database
	if ($ok == 1){

        if (!($connessione = mysqli_connect($host, $username, $password)))
            die("Connessione fallita!");
        
        if (!(mysqli_select_db($connessione, $db)))
            die("Data base non trovato!");		

		$sql="UPDATE `unit` SET `URI` = '$new_filename' WHERE `unit`.`idunit` = '$unit';";
		//echo "$sql";
		if (!($result = mysqli_query($connessione, $sql))){
		 die("Non riesco a aggiornare il db con il nuovo file");}
		 {
		 	
			//echo "<img id=\"clippy\" src=\"clips/$nome\" />";
			echo $new_target_file;
			
		 	} 
	 	} else {echo "fail";}
 }

?>

