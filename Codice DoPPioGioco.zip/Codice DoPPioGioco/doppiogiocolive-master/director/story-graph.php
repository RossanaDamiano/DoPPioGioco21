<!doctype html>
<head>
<link rel="stylesheet" type="text/css" href="doppiogioco_console.css">

</head>
<body>
<div id="container">
<header>
</header>
<div id="main">

<h3>Tabella della <a href="../index.php">storia</a></h3>

<p>La tabella seguente rappresenta tutte coppie di clip in cui la seconda segue la prima</p>

<table>

<tr><th>Precede</th><th>Segue</th><th>Cancella</th></tr>

<?php

include '../include/connessione.php';

if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");		


$sql = "SELECT * FROM `story_graph` JOIN `unit` ON `unit_idunit-after` = `unit`.`idunit`;";
//echo $sql;

if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a leggere lo story graph");

	 
while ($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$title_after = $riga["title"];
			$unit_before = $riga["unit_idunit-before"];
			$unit_after = $riga["unit_idunit-after"];
			echo "<tr><td>";
				$query_before = "SELECT `title` FROM `unit` WHERE `idunit` = '$unit_before'";
				//echo $query_before;
				if (!($result_before = mysqli_query($connessione, $query_before)))
						 die("Non riesco a leggere il titolo della clip che precede");
				$row = mysqli_fetch_array($result_before);
				$title_before = $row["title"];
                // http://labinterdisciplinare1516.altervista.org/doppiogioco/director/index_unit.php?unit=11
                echo "<a href=\"index_unit.php?unit=$unit_before\">";
				//echo "<a href=\"visualizzaUnit.php?unit=$unit_before\">";
				echo "$title_before</a>";
			echo "</td><td>";
			echo "<a href=\"index_unit.php?unit=$unit_after\">";
			// echo "<a href=\"visualizzaUnit.php?unit=$unit_after\">";
			echo "$title_after</a>";
			echo "</td><td><a href=\"cancellaDaStoryGraph.php?before=$unit_before&after=$unit_after\">cancella</a></td></tr>";			
}	

?>

</table>

<p><a href="matrix.php">vedi la storia come matrice</a></p>

</div>
<footer>
</footer>
</div>
</body>
</html>