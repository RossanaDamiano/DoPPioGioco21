<!doctype html>
<head>
<!--<link rel="stylesheet" type="text/css" href="doppiogioco_console.css">-->
<link href="labidsi.css" rel="stylesheet" type="text/css" media="screen" />
<script>

function modificaCoppia(precede,segue,flag) {
    if (unit == "") {
        document.getElementById(type).innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById(type).innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","modificaCoppia.php?precede="+precede+"&"+"segue="+segue+"&"+"flag="+flag,true);
        xmlhttp.send();
    }
}


</script>
</head>
<body>



<!--<div id="table_container">-->

<h3>Tabella della <a href="../index.php">storia</a></h3>


<table style="width:100%;background-color:#d7c987">

<?php

// le celle della tabella contengono un checkbox che cancella / inserisce una coppia di unit
// qui leggo lo stato di ogni coppia e genero un checkbox checked / unchecked di conseguenza 

include '../include/connessione.php';

if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");		
	 
$sql = "SELECT * FROM story_graph";

if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a leggere lo story graph");


//creo array delle adiacenze
//array associativo con id della unit che precede come chiave e id della unit che segue come valore 
$array_coppie = array();

while ($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$title_after = $riga["title"];
			$unit_before = $riga["unit_idunit-before"];
			$unit_after = $riga["unit_idunit-after"];
			$array_coppie[$unit_before] = $unit_after;			
}			

//print_r ($array_coppie);


//creo array delle unit (i valori sono i titoli)
$sql = "SELECT * FROM unit WHERE `in_use` = 1";
if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a leggere la lista delle unit");

$array_unit = array();	
$array_unit2 = array(); 
	 
while ($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$idunit = $riga["idunit"];
			$title = $riga["title"];
			$array_unit[$idunit] = $title;		
			$array_unit2[] = $idunit;		
}
echo "<br/>";

//print_r ($array_unit);

//creo la prima riga
echo "<tr><td></td>";
foreach ($array_unit as $key => $value) {
	echo "<td><a href=\"index_unit.php?unit=$key\">$value</a></td>";	
}	
echo "</tr>";	


//ciclo su array delle unit
//per ogni unit, creo tante celle quante sono le unità nel sistema, e per ogni unità verifico: 
//se la trovo nell'array delle adiacenze accedendo con l'id dell'unità, metto il checkbox a checked


foreach ($array_unit as $key => $value) {
	//per ogni unit una riga di tabella
	echo "<tr>";
	//echo "<td>$value ($key)</td>";
    echo "<td><a href=\"index_unit.php?unit=$key\">$value</a></td>";
	
		for ($i = 0; $i < count($array_unit2); ++$i){
			$match = $array_coppie[$key];
			echo "<td>";
			//echo $array_unit2[$i];
			//echo "($match)";
			echo "<input type=\"checkbox\"";
			if ($match == $array_unit2[$i]){
				//echo "X";
				echo " checked ";
				}
				echo "/>";
			echo "</td>";
		}
						
	echo "</tr>";
}	





//ogni checkbox chiama a onchange una funzione che mette/toglie la coppia dal grafo della storia.



?>

</table>
<!--</div>-->


</body>
</html>





