<?php
include '../include/connessione.php';

$unit = $_REQUEST["unit"];
$type = $_REQUEST["type"];
$value = $_REQUEST["value"];
$value = addslashes($value);

//echo "unit = $unit ";
//echo "type = $type ";
//echo "value = $value ";

//UPDATE `unit` SET `notes` = 'unit di prova prova' WHERE `unit`.`idunit` = 3;

//TODO controllare che la unit non esista già con un certo titolo!
//posso mettere lo stesso titolo solo se è uguale a quello precedente della stessa Unit

if ($_REQUEST["value"] == 'nuovo titolo') {die ("inserisci un nuovo titolo");}


if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");	


$sql = "SELECT * FROM `unit` WHERE `idunit` = '$_REQUEST[unit]';";
//echo $sql;
if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a leggere i dati della clip");
$u = mysql_fetch_assoc($result);	 
//print_r ($u);
//echo " initial: $u[initial] ";
$nome = $u["title"];


//Controllo che la unit non sia finale e iniziale al tempo stesso	 
if (($type == "final") AND ($value == 1)) {
	if ($u["initial"] == 1) {
		die ("Attenzione: non puoi mettere come finale una clip iniziale");
		//echo "ciao ";
		}

	}

if (($type == "initial") AND ($value == 1)) {
	if ($u["final"] == 1) {
		die ("Attenzione: non puoi mettere come iniziale una clip finale");
		//echo "ciao ";
		}

	}
	

//controllo che la unit non diventi finale se è la prima di una coppia
$sql = "SELECT * FROM `story_graph` WHERE `unit_idunit-before` = '$unit';";
if (($type == "final") AND ($value == 1)){
	if (!($result = mysqli_query($connessione, $sql)))
	 	die("Non riesco a consultare il grafo della storia"); 
	if (mysqli_num_rows($result)>0){
		die("Non puoi rendere finale la clip $nome,<br/>ha delle clip che la seguono nella storia");	
	}
}

//controllo che la unit non diventi iniziale se è la seconda di una coppia
$sql = "SELECT * FROM `story_graph` WHERE `unit_idunit-after` = '$unit';";
if (($type == "initial") AND ($value == 1)){
	if (!($result = mysqli_query($connessione, $sql)))
	 	die("Non riesco a consultare il grafo della storia"); 
	if (mysqli_num_rows($result)>0){
		die("Non puoi rendere iniziale la clip $nome, segue alcune clip nella storia");	
	}
}


$sql="UPDATE `unit` SET `$type` = '$value' WHERE `unit`.`idunit` = '$unit';";
//echo $sql;



if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a effettuare la modifica");


$sql = "SELECT * FROM `unit` WHERE `idunit` = '$unit';";

if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a leggere i dati della clip");
	 
$unit = mysqli_fetch_array($result, MYSQLI_ASSOC);

//title URI notes initial emotion

$title = $unit["title"];
$id = $unit["idunit"];
$notes = $unit["notes"];
$initial = $unit["initial"];
$emotion = $unit["emotion"];
$clip = $unit["clip"];	

//Stampo la nuova unit
//falle scrivere nei campi già esistenti

if (($type == "final") AND ($value == 1)) {echo "si";} 
if (($type == "final") AND ($value == 0)) {echo "no";} 

if (($type == "initial") AND ($value == 1)) {echo "si";} 
if (($type == "initial") AND ($value == 0)) {echo "no";} 

//echo "type: $type ";

if (($type == 'title') OR ($type == 'notes')){
	echo "$unit[$type]";
}




?>