<?php

include '../include/connessione.php';
include '../include/utilities.php';

$title = $_REQUEST["title"];

//verifico se esiste già una unit con il titolo dato
$sql = "SELECT * FROM `unit` WHERE `title` = '$title'";
         
if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a effettuare il controllo sul titolo!");  
	 
if (mysqli_num_rows($result) > 0){
	
	die ( "doppione");
	
	}	 


//se non esiste, la creo
else{
	
		
	$sql = "INSERT INTO `unit` (`title`) VALUES ('$title');";																				
	//echo "<br/> $sql <br/>";
         
	
	if (!($result = mysqli_query($connessione, $sql)))
		 die("Inserimento dati fallito!");     				

	//echo "inserimento effettuato";
	
	$sql = "SELECT * FROM `unit` WHERE `title` = '$title';"; 
	if (!($result = mysqli_query($connessione, $sql)))
	 	die("Non trovo la clip inserita!");  

	$unit = mysqli_fetch_array($result, MYSQLI_ASSOC);
	$unit_id = $unit["idunit"];
	$unit_title = $unit["title"];
	
	
	//echo $unit_title;
	echo $unit_id;

}
?>