<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Author" content="Vincenzo Lombardo">
<meta name="Description" content="www.cirma.unito.it/labidsi">
<meta name="KeyWords" content="Vincenzo Lombardo, Rossana Damiano, Antonio Pizzo, Laboratorio interdisciplinare, DAMS">
<title>Laboratorio di storie interattive</title>

<link href="../labidsi.css" rel="stylesheet" type="text/css" media="screen" />
<link href="labidsi_unit.css" rel="stylesheet" type="text/css" media="screen" />

<script src="../javascriptesterno01.js" type="text/javascript"></script>

</head>

<body onload="document.modifica.reset();document.fileclip.reset();document.storia.reset();">
<div id="titolo">
  <br/>
  <h1><center>- DoPPioGioco Director -</center></h1>
</div>
<!-- div id="distance"></div -->
<div id="container">

<!-- QUADRANTE 1 METADATI A-SX -->
  <div id="metadata">
		<div id="metadata_title">
      <div id="homebutton">
        <a href="../index.php"><img src="../immagini/hp_storia.png" width="70" height="25" id="Image2" /></a>
      </div>
      Unit Metadata
    </div>

    <div id="metadata_table">

			<form name="modifica">
				<input type="hidden" id="mio_id" name="mio_id" />
				<input type="hidden" id="mia_immagine" name="mia_immagine">

        <table class="metadata_table" font-size="8pt">
          <thead>
            <tr>
              <th class="row-1 row-ID"></th>
              <th class="row-2 row-name"></th>
              <th class="row-3 row-job"></th>
              <th class="row-4 row-email"><th>
            </tr>
          </thead>
          <tbody>

			<?php
			  include '../include/connessione.php';
			  include '../include/utilities.php';
			  if (!($connessione = mysqli_connect($host, $username, $password)))
					die("Connessione fallita!");

				if (!(mysqli_select_db($connessione, $db)))
					die("Data base non trovato!");	

			  if (isset($_REQUEST["unit"])){
			    // inizializzazione
				  $unit = $_REQUEST["unit"];
			    $metadati = leggiMetadatiUnit($unit,$connessione);
			    if ($metadati["initial"] == 1){$initial_d = "si"; $i_checked_si = " checked"; $i_checked_no = "";} else {$initial_d = "no"; $i_checked_no = " checked"; $i_checked_si = "";}
			    if ($metadati["final"] == 1){$final_d = "si"; $f_checked_si = " checked"; $f_checked_no = "";} else {$final_d = "no"; $f_checked_no = " checked"; $f_checked_si = "";}

			    $metadati_title  = stripslashes($metadati["title"]);
			    $metadati_notes  = stripslashes($metadati["notes"]);

				  echo "<input type=\"hidden\" id=\"check\" value=\"1\" />";
				  echo "<tr>";
						echo "<td> <div style=\"height:10px; max-height:10px; min-height:10px; \">titolo:</div></td>";
					  echo "<td id=\"title\" style=\"width:150px; max-width:150px\"><div style=\"height:10px; max-height:10px; min-height:10px; \">$metadati_title</div></td>";
					  echo "<td style=\"background-color:yellow\"><div style=\"height:10px; max-height:10px; min-height:10px; \"><input id=\"tit\" name=\"titolo\" type=\"text\" value=\"$metadati_title\" /></div></td>";
				    echo "<td><div style=\"height:10px; max-height:10px; min-height:10px; \"><input type=\"button\" value=\"modifica\" onclick=\"modificaElementoInUnit($unit,document.modifica.titolo.value,'title');\"/></div></td>";
					echo "</tr>";

				  echo "<tr>";
						echo "<td><div style=\"height:10px; max-height:10px; min-height:10px; \">note:</td>";
						echo "<td id=\"notes1\"><div id=\"notes\" style=\"width:150px; max-height:60px; overflow-y:scroll \">$metadati_notes</div></td>";
						echo "<td style=\"background-color:yellow\"><textarea id=\"notes2\" name=\"note\" value=\"nuove note\" style=\"max-width:150px; max-height:60px\" \>$metadati_notes</textarea></td>";
				    echo "<td><div style=\"height:10px; max-height:10px; min-height:10px; \"><input type=\"button\" value=\"modifica\" onclick=\"modificaElementoInUnit($unit,document.modifica.note.value,'notes');\"/></td>";
					echo "</tr>";

				  echo "<tr>";
						echo "<td>initial:</td>";
						echo "<td id=\"initial\">$initial_d</td>";
						echo "<td style=\"background-color:yellow\">SI<input name=\"initial\" type=\"radio\" value=\"1\" onchange=\"modificaElementoInUnit($unit,1,'initial');\" $i_checked_si > &nbsp; NO<input name=\"initial\" type=\"radio\" value=\"0\" onchange=\"modificaElementoInUnit($unit,0,'initial');\"  $i_checked_no></td>";
				    echo "<td></td>";
					echo "</tr>";

				  echo "<tr>";
						echo "<td>final:</td>";
						echo "<td id=\"final\">$final_d</td>";
						echo "<td style=\"background-color:yellow\">SI<input name=\"final\" type=\"radio\" value=\"1\" onchange=\"modificaElementoInUnit($unit,1,'final');\" $f_checked_si > &nbsp; NO<input name=\"final\" type=\"radio\" value=\"0\" onchange=\"modificaElementoInUnit($unit,0,'final');\"  $f_checked_no></td>";
				    echo "<td></td>";
					echo "</tr>";
				} else {
			    echo "<input type=\"hidden\" id=\"check\" value=\"0\" />";
			    echo "<tr>";
						echo "<td>titolo:</td>";
						echo "<td id=\"title\" style=\"width:150px; max-width:150px\">nessun titolo</td>";
						echo "<td style=\"background-color:yellow\"><input id=\"tit\" name=\"titolo\" type=\"text\" value=\"scrivi un titolo\"></td>";
			      echo "<td><input type=\"button\" id=\"pulsantecrea\" value=\"CREA\" onclick=\"switchCreation(document.modifica.mio_id.value,document.modifica.titolo.value,'title');\"/></td>";
					echo "</tr>";

					echo "<tr>";
			      echo "<td>note:</td>";
						echo "<td id=\"notes\" style=\"width:150px; max-width:150px\">--------</td>";
						echo "<td style=\"background-color:yellow\"><textarea name=\"note\" value=\"nuove note\" > </textarea></td>";
			      echo "<td><input type=\"button\" value=\"modifica\" onclick=\"modificaElementoInUnit(document.modifica.mio_id.value,document.modifica.note.value,'notes');\"/></td>";
					echo "</tr>";

					echo "<tr>";
			      echo "<td>initial:</td>";
						echo "<td id=\"initial\">no</td>";
						echo "<td style=\"background-color:yellow\">SI<input name=\"initial\" type=\"radio\" value=\"1\" onchange=\"modificaElementoInUnit(document.modifica.mio_id.value,1,'initial');\" > &nbsp; NO<input name=\"initial\" type=\"radio\" value=\"0\" onchange=\"modificaElementoInUnit(document.modifica.mio_id.value,0,'initial');\"></td>";
			      echo "<td></td>";
			    echo "</tr>";

			    echo "<tr>";
			      echo "<td>final:</td>";
						echo "<td id=\"final\">no</td>";
						echo "<td style=\"background-color:yellow\">SI<input name=\"final\" type=\"radio\" value=\"1\" onchange=\"modificaElementoInUnit(document.modifica.mio_id.value,1,'final');\" > &nbsp; NO<input name=\"final\" type=\"radio\" value=\"0\" onchange=\"modificaElementoInUnit(document.modifica.mio_id.value,0,'final');\" ></td>";
			      echo "<td></td>";
					echo "</tr>";
			  }
			  ?>
			  </form>

			  <tr>
					<td></td>
					<td></td>
					<td></td>
					<td><div style=\"height:10px; max-height:10px; min-height:10px; \">
				    <?php
				      if (isset($_REQUEST["unit"])){
					      echo "<input type =\"button\" value=\"delete unit\" onclick=\"cancellaUnit($_REQUEST[unit]);document.modifica.reset();document.fileclip.reset();document.storia.reset();window.location.href='index_unit.php';window.location.search='index_unit.php';\" /> ";
					      echo "<span id=\"info-delete\"></span>";
				      }
				    ?>
          </div>
			    </td>
				</tr>
			  <tr>
					<td></td>
					<td></td>
					<td></td>
					<td><div style=\"height:10px; max-height:10px; min-height:10px; \"><a href="index_unit.php"><img src="../immagini/nuova_unit.png" width="28px" height="10px" id="Image3" /></a></div></td>
				</tr>

      </tbody>

			</table>
		</form>

			<form id="file-form"  name="fileclip"" method="POST" enctype="multipart/form-data">
				<input type="file" id="file-select" name="photo"/>
			</form>
			<?php
			  if (isset($_REQUEST["unit"])){
				  echo "<button id=\"pulsante\" onclick=\"inviaForm($unit);\">Carica il file</button>";
			  } else {
				  echo "<button id=\"pulsante\" onclick=\"inviaForm(document.modifica.mio_id.value);\">Carica il file</button>";
			  }
			?>


    </div> <!-- fine metadata_table -->

  </div> <!-- fine metadata -->

<!-- QUADRANTE 2 CLIP A-DX -->
  <div id="clip">

    <div id="cliptitle">
      <p> Clip title </p>
      
      <?php
      	$my_notes = addslashes($metadati_notes);
        echo "<button onclick=\"document.getElementById('clipscreen').innerHTML =  '$my_notes'; \" ";
        echo ">see notes</button>  ";
        ?>
      
      
    </div>
    <!--<div id="mynotes"> ... </div> -->
    <div id="clipscreen" style="overflow-y:auto">
      <?php
      	if (isset($_REQUEST["unit"])){
      		if ($metadati["clip"] != "") {
						echo "<img id=\"clippy\" name=\"clippy\" position=\"center\" src=\"../clips/$metadati[clip]?78965\" width=\"scaleSize(\"../clips/$metadati[clip]\")[0]\" height=\"scaleSize(\"../clips/$metadati[clip]\")[1]\" />";
      		  // echo "<img id=\"clippy\" name=\"clippy\" src=\"../clips/$metadati[clip]\" />";
    	  	  $image_loaded = 'true';
    		  } else {
    			  //$notes_mirror = $metadati["notes"];
    			  echo "<img id=\"clippy\" name=\"clippy\" /><p id=\"notes_mirror\">$metadati_notes</p>";
      		}
      	} else {
					echo "<img id=\"clippy\" name=\"clippy\" /><p id=\"notes_mirror\"></p>";
				}
	    ?>
    </div>


</div>

<!-- QUADRANTE 3 EMOZIONI B-SX -->
  <div id="annotazione">
    <div id="annotation_title">
      <p> Annotation of emotions <span id="ewarn"></span></p>
    </div>

		<div id="annotation_quadrants">
      <table style="width:100%">

        <?php

        $array_emonames = array("amusement", "pride", "joy", "relief", "interest", "pleasure", "hot anger", "panic fear", "despair",  "irritation", "anxiety", "sadness");

        $P1 = array("amusement", "relief");
        $P2 = array("pride", "interest");
        $P3 = array("joy", "pleasure");
        $N1 = array("hot anger", "irritation");
        $N2 = array("panic fear", "anxiety");
        $N3 = array("despair", "sadness");

        $PH = array("amusement", "pride", "joy");
        $PL = array("relief", "interest", "pleasure");
        $NH = array("hot anger", "panic fear", "despair");
        $NL = array("irritation", "anxiety", "sadness");

        $array_emotions = leggiEmozioniUnit($unit,$connessione);


        echo "<tr>";
          echo "<td colspan=\"3\" style=\"color: grey\">Positive, High intensity</td>";
          echo "<td colspan=\"3\" style=\"color: grey\">Positive, Low intensity</td>";
        echo "</tr>";

        echo "<tr></tr>";

        $td_count = 0;
        echo "<tr>";
        foreach ($P1 as $name){
        	echo "<td id=\"$name\" >$name</td><td><input type=\"checkbox\" ";
        	if ($array_emotions[$name]){echo " checked ";}
        	if (isset($_REQUEST["unit"])){
        		echo "onchange=\"changeEmotion($unit,'$name',this.checked,'$name')\" />";
        	} else {
        		echo "onchange=\"changeEmotion(document.modifica.mio_id.value,'$name',this.checked,'$name')\" />";
        	}
        	echo "</td><td>&nbsp;</td>";
        	$td_count++;
        }
        echo "</tr>";

        $td_count = 0; echo "<tr>";
        foreach ($P2 as $name){
        	echo "<td id=\"$name\" >$name</td><td><input type=\"checkbox\" ";
        	if ($array_emotions[$name]){echo " checked ";}
        	if (isset($_REQUEST["unit"])){
        		echo "onchange=\"changeEmotion($unit,'$name',this.checked,'$name')\" />";
        	} else {
        		echo "onchange=\"changeEmotion(document.modifica.mio_id.value,'$name',this.checked,'$name')\" />";
        	}
        	echo "<td></td>&nbsp;</td>";
        	$td_count++;
        }
        echo "</tr>";

        $td_count = 0; echo "<tr>";
        foreach ($P3 as $name){
        	echo "<td id=\"$name\" >$name</td><td><input type=\"checkbox\" ";
        	if ($array_emotions[$name]){echo " checked ";}
        	if (isset($_REQUEST["unit"])){
        		echo "onchange=\"changeEmotion($unit,'$name',this.checked,'$name')\" />";
        	} else {
        		echo "onchange=\"changeEmotion(document.modifica.mio_id.value,'$name',this.checked,'$name')\" />";
        	}
        	echo "</td><td>&nbsp;</td>";
        	$td_count++;
        }
        echo "</tr>";

        echo "<tr><td>&nbsp;</td></tr>";

        echo "<tr>";
          echo "<td colspan=\"3\" style=\"color: grey\">Negative, High intensity</td>";
          echo "<td colspan=\"3\" style=\"color: grey\">Negative, Low intensity</td>";
        echo "</tr>";

        $td_count = 0; echo "<tr>";
        foreach ($N1 as $name){
        	echo "<td id=\"$name\" >$name</td><td><input type=\"checkbox\" ";
        	if ($array_emotions[$name]){echo " checked ";}
        	if (isset($_REQUEST["unit"])){
        		echo "onchange=\"changeEmotion($unit,'$name',this.checked,'$name')\" />";
        	} else {
        		echo "onchange=\"changeEmotion(document.modifica.mio_id.value,'$name',this.checked,'$name')\" />";
        	}
        	echo "</td><td>&nbsp;</td>";
        	$td_count++;
        }
        echo "</tr>";

        $td_count = 0; echo "<tr>";
        foreach ($N2 as $name){
        	echo "<td id=\"$name\" >$name</td><td><input type=\"checkbox\" ";
        	if ($array_emotions[$name]){echo " checked ";}
        	if (isset($_REQUEST["unit"])){
        		echo "onchange=\"changeEmotion($unit,'$name',this.checked,'$name')\" />";
        	} else {
        		echo "onchange=\"changeEmotion(document.modifica.mio_id.value,'$name',this.checked,'$name')\" />";
        	}
        	echo "</td><td>&nbsp;</td>";
        	$td_count++;
        }
        echo "</tr>";

        $td_count = 0;
        echo "<tr>";
        foreach ($N3 as $name){
        	echo "<td id=\"$name\" >$name</td><td><input type=\"checkbox\" ";
        	if ($array_emotions[$name]){echo " checked ";}
        	if (isset($_REQUEST["unit"])){
        		echo "onchange=\"changeEmotion($unit,'$name',this.checked,'$name')\" />";
        	} else {
        		echo "onchange=\"changeEmotion(document.modifica.mio_id.value,'$name',this.checked,'$name')\" />";
        	}
        	echo "</td><td>&nbsp;</td>";
        	$td_count++;
        }
        echo "</tr>";

        ?>
      </table>

    </div>
  </div>


<!-- QUADRANTE 4 CONTINUAZIONE B-DX -->
  <div id="continuazione">
    <div id="continuation_title">
      <p> Continuations</p>
    </div>

<div id="continuation_lists">
 <form name="storia"> <div id="modifiche" style="overflow-y:auto">

<?php

echo "<p>Scegli le unit che vuoi aggiungere come continuazione:</p>";

$sql = "SELECT `title`, `idunit` FROM `unit` WHERE `in_use` = 1 and `initial` = 0 ORDER BY `title`;";

if (!($result = mysqli_query($connessione, $sql)))
	 die("Non trovo la lista delle clip");

while($cand_unit = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$candidata = $cand_unit["idunit"];
		$nome = stripslashes($cand_unit["title"]);
		//echo "nome = $nome - REQUEST = $_REQUEST[unit]";
		//non si può fare questo check sulla nuova unit... va fatto nell'aggiunta
		if ($candidata != $unit) {
			if (isset($_REQUEST["unit"])){
			echo "<input type=\"button\" value=\"$nome\" onclick=\"putInStory($candidata,$unit)\" /> ";
			}
			else {
				echo "<input type=\"button\" value=\"$nome\" onclick=\"putInStory($candidata,document.modifica.mio_id.value)\" /> ";
			}
			//echo "inserisci $candidata e $_REQUEST[unit] <br/>";
		}
}


?>

</div></form>
<br/>
<div id="unit_dopo" style="overflow-y:auto">
<?php

echo "<p>Lista delle unit che seguono:</br>";
$sql = "SELECT * FROM `story_graph` JOIN `unit` ON `unit_idunit-after` = `unit`.`idunit` WHERE `unit_idunit-before`='$unit' ORDER BY `title`;";
//echo "$sql";
if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a leggere lo story graph");

while ($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$unit_after = $riga["title"];
			$id_after = $riga["unit_idunit-after"];
			echo "<span>";
			echo "<a href=\"index_unit.php?unit=$id_after\">";
			echo "$unit_after</a>";
			echo "<input type=\"button\" value=\"rimuovi\" onclick=\"removeFromStory('$unit','$id_after','new')\" /> ";
			//(<a href=\"cancellaCoppiaStoryGraph.php?id_before=$unit&id_after=$id_after\")>rimuovi</a>) ";
			echo "</span>";
}

?>

  </div>
</div>

</div>

</body>
</html>
