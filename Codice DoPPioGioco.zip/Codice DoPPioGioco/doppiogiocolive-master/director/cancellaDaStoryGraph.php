<?php


include '../include/connessione.php';

//la unit che segue
$before =  $_REQUEST["before"];

//la unit che precede
$after = $_REQUEST["after"];

//story
$story = 3;

//"DELETE FROM `story_graph` WHERE `story_graph`.`story_idstory` = '$story' AND `story_graph`.`unit_idunit-before` = '$before' AND `story_graph`.`unit_idunit-after` = '$after' ";

$sql = "DELETE FROM `story_graph` WHERE `story_graph`.`story_idstory` = '$story' AND `story_graph`.`unit_idunit-before` = '$before' AND `story_graph`.`unit_idunit-after` = '$after' ";

if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");	 	 	
	 
if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a cancellare la coppia di clip dalla storia");	 						


$sql = "SELECT `title` FROM `unit`  WHERE `idunit`='$after';";
if (!($result = mysqli_query($connessione, $sql)))
		 die("Non riesco a trovare la clip rimossa");
$clip_rimossa = mysqli_fetch_array($result, MYSQLI_ASSOC);
//echo "rimossa dalle clip successive la clip - $clip_rimossa[title]";

// questa parte si deve generare solo se il flag new è settato
if (isset($_GET["nuova"])) {
	
	
	$sql = "SELECT `title` FROM `unit`  WHERE `idunit`='$before';";
	if (!($result = mysqli_query($connessione, $sql)))
		 die("Non riesco a trovare la clip");
	$clip_before = mysqli_fetch_array($result, MYSQLI_ASSOC);

	echo "<p>Lista delle unit che seguono $clip_before[title]: </br>";
	$sql = "SELECT * FROM `story_graph` JOIN `unit` ON `unit_idunit-after` = `unit`.`idunit` WHERE `unit_idunit-before`='$before';";
	//echo "$sql";
	if (!($result = mysqli_query($connessione, $sql)))
		 die("Non riesco a leggere lo story graph");
	 
	while ($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$unit_after = stripslashes($riga["title"]);
			$unit_after_id = $riga["idunit"];
			echo "<span>";
			echo "$unit_after <a href=\"visualizzaUnit.php?unit=$unit_after_id\">visualizza</a>  ";
			echo "<input type=\"button\" value=\"rimuovi\" onclick=\"removeFromStory('$before','$unit_after_id','new')\" /> ";
			//echo "removeFromStory('$before','$unit_after_id','new')";
			echo "</span>";
}	

}

else {
	echo "<!doctype html><head>";
	echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"doppiogioco_console.css\">";
	echo "</head><body>";
	echo "<div id=\"container\"><header></header>";
	echo "<div id=\"main\">";
	echo "<div><p>Cancellazione effettuata</p></div>";	
	echo "</div><footer></footer></div></body></html>";
}


?>