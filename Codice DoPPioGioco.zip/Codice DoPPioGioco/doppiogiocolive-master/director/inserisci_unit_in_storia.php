<?php
include '../include/connessione.php';

//la unit che segue
//$clip =  $_REQUEST["clip"];
$after =  $_REQUEST["after"];


//la unit che precede
//$unit = $_REQUEST["unit"];
$before = $_REQUEST["before"];


//INSERT INTO `doppiogioco`.`story_graph` (`story_idstory`, `unit_idunit-before`, `unit_idunit-after`, `idstory_has_unit`) VALUES ('1', '3', '4', NULL);


if (!($connessione = mysql_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysql_select_db($db,$connessione)))
	 die("Data base non trovato!");	 	 																						 

/*
if (isset($_REQUEST["id"])){
	$idunit = $_REQUEST["id"];
	$sql = "SELECT * FROM `unit` WHERE `idunit` = '$idunit';"; 
	//echo $sql;
	if (!($result = mysqli_query($connessione, $sql)))
	 die("Devi prima inserire la nuova unit!");	 
	$unit = mysqli_fetch_array($result, MYSQLI_ASSOC);  
	$title_id = $unit["title"]; 
	}
	else {
	//Se non abbiamo l'id della unit la ricaviamo dal data base
	$sql = "SELECT idunit FROM `unit` WHERE `title` = '$unit';"; 
	//echo $sql;
	if (!($result = mysqli_query($connessione, $sql)))
	 die("Non trovo la unit!");
	if (mysqli_num_rows($result) == 0)
		die("la unit $unit non esiste"); 
	$unit = mysqli_fetch_array($result, MYSQLI_ASSOC);  
	$idunit = $unit["idunit"]; 
	}
*/

//controllo che non esista già la coppia 

$sql = "SELECT * FROM `story_graph` WHERE `unit_idunit-before`='$before' AND `unit_idunit-after`='$after'";
//echo "prima query $sql";
if (!($result = mysqli_query($connessione, $sql)))
	 die("Consultazione dello story graph fallita!");	 
	// aggiungo solo se esiste
	if ((mysqli_num_rows($result) == 0) AND ($before != $after)){						
	//unit_idunit-before $idunit
	//unit_idunit-after $clip
	$sql = "INSERT INTO `story_graph` (`story_idstory`, `unit_idunit-before`, `unit_idunit-after`) VALUES ('3', '$before', '$after');";
	//echo "seconda query: $sql";
	if (!($result = mysqli_query($connessione, $sql)))
		 die("Inserimento nello story graph fallito!");
	}	
	
//controlla anche che non segua se stessa!!	

		 

//echo "<p>Lista delle unit che seguono $_REQUEST[unit]: </br>";
echo "<p>Lista delle unit che seguono: </br>";
$sql = "SELECT * FROM `story_graph` JOIN `unit` ON `unit_idunit-after` = `unit`.`idunit` WHERE `unit_idunit-before`='$before';";
//echo " terza query $sql";
if (!($result = mysqli_query($connessione, $sql)))
		 die("Non riesco a leggere lo story graph");	 
	
//genero sempre la lista delle unit che seguono	 
while ($riga = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$unit_after = stripslashes($riga["title"]);
			$unit_after_id = $riga["idunit"];
			echo "<span>";
			echo "<a href=\"index_unit.php?unit=$unit_after_id\")>$unit_after</a> ";
			// aggiungere link per remove
			//return theFunction();
			echo "<input type=\"button\" value=\"rimuovi\" onclick=\"removeFromStory('$before','$unit_after_id','new')\" /> ";
			echo "</span>";
}	

echo "</p>";

?>
