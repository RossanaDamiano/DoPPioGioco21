<!doctype html>
<head>
</head>
<body>
<div id="container">
<header>
</header>
<div id="main">

<?php

include '../include/connessione.php';
$cancellanda = $_GET["id"];
//$title = $_GET["title"];

if (!($connessione = mysqli_connect($host, $username, $password)))
	 die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	 die("Data base non trovato!");	

$sql = "SELECT * FROM `unit` WHERE `idunit` = '$cancellanda'";

if (!($result = mysqli_query($connessione, $sql)))
	 die("Non riesco a trovare la unit da cancellare");
	 
$count = mysqli_num_rows($result);

if ($count == 0) {die ("nonesiste");}	 


$sql1 = "DELETE FROM `story_graph` WHERE `story_graph`.`unit_idunit-before` = '$cancellanda';";
$sql2 = "DELETE FROM `story_graph` WHERE `story_graph`.`unit_idunit-after` = '$cancellanda';";
$sql_emozioni = "DELETE FROM `unit_has_emotion` WHERE `id_unit` = '$cancellanda';";
$sql3 = "DELETE FROM `unit` WHERE `unit`.`idunit` = '$cancellanda';";
//echo $sql3;



if (!(mysql_select_db($db,$connessione)))
	 die("Data base non trovato!");	

if (!($result = mysqli_query($connessione, $sql1)))
	 die("Non riesco a cancellare la unit dalla storia (1)");
	 
if (!($result = mysqli_query($connessione, $sql2)))
	 die("Non riesco a cancellare la unit dalla storia (2)");	 



if (!($result = mysqli_query($connessione, $sql3)))
	{
		$sql_rimozione = "UPDATE `unit` SET `in_use` = '0' WHERE `unit`.`idunit` = '$cancellanda';";
			if (!($result = mysqli_query($connessione, $sql_rimozione))) {
				die ("non riesco a impostare la unit come non in uso");
				}
		} else {
        	if (!($result = mysqli_query($connessione, $sql_emozioni)))
	 		die("Non riesco a cancellare le emozioni della unit (2)");
     	}


//echo "alert(\"unit $cancellanda deleted\")";
echo "deleted";

?>


</div>
<footer>
</footer>
</div>
</body>
</html>