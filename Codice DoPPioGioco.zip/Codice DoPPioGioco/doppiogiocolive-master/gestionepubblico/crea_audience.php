<?php
include '../include/connessione.php';
include '../include/utilities.php';

if (isset($_REQUEST[nome])){

$nome = $_REQUEST["nome"];


//Todo: verifica che non esista già un utente con un certo nome...

	$sql = "INSERT INTO `audience` (`name`) VALUES ('$nome');"; 
	//echo "$sql";

	if (!($result = mysqli_query($connessione, $sql)))
	 		die("Non riesco a inserire questa persona");  

	$sql = "SELECT * FROM `audience` WHERE `name` = '$nome'";
	//echo "$sql";

	if (!($result = mysqli_query($connessione, $sql)))
	 		die("Non trovo la persona appena inserita");  

	$p =  mysqli_fetch_array($result, MYSQLI_ASSOC);

	$id_persona = $p["id_audience"];

	echo "$id_persona";

}


?>