<!doctype html>
<head>
<script>

function cancellaAudience(nome) {
    if (nome == "") {
        document.getElementById('title').innerHTML = "Attenzione: manca il nome della persona da cancellare!";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            	//document.getElementById('info1').innerHTML = xmlhttp.responseText;
            	document.getElementById('avviso').innerHTML = xmlhttp.responseText;            	
            }
        }
        xmlhttp.open("GET","cancella_audience.php?nome="+nome,true);
        xmlhttp.send();
    }
}
</script>
</head>
<body>
<div id="container">
<header>
</header>
<div id="main">
<a href="../index.php">Torna alla home</a>

<h3>Gestione audience</h3>

<div id="avviso"></div>

<p>
<?php
include '../include/connessione.php';
include '../include/utilities.php';

if (!($connessione = mysqli_connect($host, $username, $password)))
    die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
    die("Data base non trovato!");

$sql = "SELECT * FROM `audience` WHERE `active` = 1;";

if (!($result = mysqli_query($connessione, $sql)))
		die("Non riesco a leggere i dati dell'audience");  
	
	while($p = mysqli_fetch_array($result, MYSQLI_ASSOC)) {	
		$nome = $p["name"];
		$id = $p["id_audience"];
		echo "<a href=\"visualizza_audience.php?chi=$id\">$nome</a> ";
		echo "<input type=\"button\" onclick=\"cancellaAudience($id)\" value=\"cancella\" /></br>";		
	}
	

?>
</p>

<a href="visualizza_audience.php">nuova persona del pubblico</a>


</div>
<footer>
</footer>
</div>
</body>
</html>