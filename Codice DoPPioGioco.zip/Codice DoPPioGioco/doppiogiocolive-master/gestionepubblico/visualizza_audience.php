<!doctype html>
<head>
<script>

var unlock = 0;

function creaAudience(nome) {
    if (nome == "nuovo nome") {
        document.getElementById('title').innerHTML = "devi scrivere un titolo";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            	//document.getElementById('info1').innerHTML = xmlhttp.responseText;
            	document.getElementById('id_persona').value = xmlhttp.responseText;
            	unlock = 1;              	
            }
        }
        xmlhttp.open("GET","crea_audience.php?nome="+nome,false);
        xmlhttp.send();
    }
}


function manageEmotion(id,emotion,flag) {
    if (nome == "nuovo nome") {
        //document.getElementById('title').innerHTML = "devi scrivere un titolo";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        
        //document.getElementById('info').innerHTML = 'carico '+emotion;
        var uri = document.getElementById('immagine').value;
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            	document.getElementById('status').innerHTML = xmlhttp.responseText;              	
            }
        }
        xmlhttp.open("GET","manageEmotions.php?chi="+id+"&idemotion="+emotion+"&flag="+flag+"&file="+uri,true);
        xmlhttp.send();
    }
}


function inviaForm(idfile)
	{
	//if (document.getElementById('check').value == 0){return;}
  	// Get the selected files from the input.
	var files = document.getElementById(idfile).files;
	
	// Create a new FormData object.
	var formData = new FormData();
  
  	// Loop through each of the selected files.
	for (var i = 0; i < files.length; i++) {
  		var file = files[i];

  		// Check the file type.
  		if (!file.type.match('image.*')) {
    	continue;
  		}
  		
  		// Add the file to the request.
  		formData.append('photo', file, file.name); 	
  		// Files
		formData.append(name, file, file.name);
		// Blobs
		//formData.append(name, blob, file.name);
		// Strings
		//formData.append('unit', idunit);   
	}
	
	// Set up the request.
	var xhr = new XMLHttpRequest();
	
  	// Open the connection.
	xhr.open('POST', 'upload_async_audience.php', true);
	
	// Set up a handler for when the request finishes.
	xhr.onreadystatechange = function () {
  	if (xhr.status === 200) {
    	// File(s) uploaded.
    	//document.getElementById('immagine').value = xhr.responseText;
    	document.getElementById('immagine_emozione').innerHTML = xhr.responseText;
    	document.getElementById('immagine').value = xhr.responseText;
  		} else {
    		alert('An error occurred!');
  			}
		}; 		
  	// Send the Data.
	xhr.send(formData);	  
}



</script>
</head>

<?php

include '../include/connessione.php';
include '../include/utilities.php';
//include 'include/audience.php';

$chi = $_REQUEST["chi"];

if (isset($_REQUEST["chi"])){
	echo "<body onload=\"manageEmotion($chi,'none','empty')\">";
}

?>


<div id="container">
<header>
</header>
<div id="main">

<a href="index_audience.php">Torna alla gestione delle emozioni</a>

<div id="info1"></div>
<div id="info"></div>

<form name="nome" id="nome">
<!-- questo flag viene messo a si dopo la creazione della persona -->
<input type="hidden" name="ok" value="no" />
<input type="hidden" name="idpersona" id="id_persona" />
<input type="hidden" name="immagine" id="immagine" />




<?php



if (isset($_REQUEST["chi"])){
		$chi = $_REQUEST["chi"];
		echo "(Gestione persona $chi)";
		$sql = "SELECT * FROM `audience` WHERE `active` = 1 and `id_audience` = $chi;"; 
		//echo $sql;
		if (!($result = mysqli_query($connessione, $sql)))
	 		die("Non trovo questa persona nel pubblico");  
		$p =  mysqli_fetch_array($result, MYSQLI_ASSOC);
		echo "<h3>Gestione pubblico: $p[name]</h3>";
	} 
	else {	
		echo "crea nuova persona del pubblico <input type=\"text\" name=\"nuovo_nome\" value=\"nome\" / >";
		//echo "<input type=\"button\" value=\"crea\" onclick=\"creaAudience(document.nome.nuovo_nome.value);\" />";
		echo "<input type=\"button\" value=\"crea\" onclick=\"creaAudience(document.nome.nuovo_nome.value);manageEmotion(document.nome.idpersona.value,'none','empty');\" />";
	}
?>

</form>
<hr/ >

<div id="immagine_emozione"></div>	

<!--<p>emozioni disponibili <span id="nuova_persona"></span></p>-->


<div id="status">

<!-- lista emozioni presenti nel sistema -->

</div>



</div>
<footer>
</footer>
</div>
</body>
</html>