<?php

include '../include/connessione.php';
include '../include/utilities.php';
//include 'include/audience.php';




$id = $_REQUEST["chi"];

$idemotion = $_REQUEST["idemotion"];

$flag = $_REQUEST["flag"];

//echo "<p>Entro con $idemotion</p>";
	

//adds, removes or changes the emotion list of an audience id
//flag = {change, remove, add, empty}
//empty is the flag when the page visualizza_audience.php is called

/*if (!($connessione = mysqli_connect($host, $username, $password)))
	die("Connessione fallita!");*/

function getAudienceEmotions($id,$connessione){
		/*if (!(mysqli_select_db($connessione, $db)))
			die("Data base non trovato!");*/	

		$emotion_list = array();
		$sql = "SELECT * FROM (`audience_has_emotion` JOIN emotion ON `emotion` = `idemotion`) WHERE `idaudience` = $id;";
		//echo $sql;
		
		if (!($result = mysqli_query($connessione, $sql)))
			die("Non riesco a leggere le emozioni dell'audience"); 
			 
		while($e = mysqli_fetch_array($result, MYSQLI_ASSOC)) {	
			//$emotion_id = $e["idemotion"];
			$emotion_name = $e["emotion name"];		
			$emotion_list[] = $emotion_name;		
	}
//print_r($emotion_list);				
return $emotion_list;
}


function getAudienceEmotionFiles($id,$connessione){

		/*if (!(mysqli_select_db($connessione, $db)))
			die("Data base non trovato!");	*/

		$emotion_files = array();
		$sql = "SELECT * FROM (`audience_has_emotion` JOIN emotion ON `emotion` = `idemotion`) WHERE `idaudience` = $id;";
		//echo $sql;
		
		if (!($result = mysqli_query($connessione, $sql)))
			die("Non riesco a leggere le emozioni dell'audience");  
			
		while($e = mysqli_fetch_array($result, MYSQLI_ASSOC)) {	
			//$emotion_id = $e["idemotion"];
			$emotion_name = $e["emotion name"];		
			$emotion_file = $e["URI"];
			$emotion_files[$emotion_name] = $emotion_file;		
	}
//print_r($emotion_files);				
return $emotion_files;
}


$array_emotions = array("amusement" => 1, "pride" => 2, "joy" => 3, "relief" => 4, "interest" => 5, "pleasure" => 6, "hot anger" => 7, "panic fear" => 8, "despair" => 9,  "irritation" => 10, "anxiety" => 11, "sadness" => 12);

$array_emonames = array("", "amusement", "pride", "joy", "relief", "interest", "pleasure", "hot anger", "panic fear", "despair",  "irritation", "anxiety", "sadness"); 


//$input_emotion = $array_emotions[$idemotion];


//adding
//mettere il controllo che non esista già...
if (($flag == "add")&&(isset($_REQUEST["file"]))){
	$file = $_REQUEST["file"];
	$sql_add = "INSERT INTO `audience_has_emotion` (`emotion`, `URI`, `idaudience`) VALUES ('$idemotion', '$file', '$id');";
	/*if (!(mysqli_select_db($connessione, $db)))
		die("Data base non trovato!");	*/
	if (!($result = mysqli_query($connessione, $sql_add)))
			die("Non riesco a aggiungere la nuova emozione all'audience selezionata");  
	echo "aggiunta emozione $array_emonames[$idemotion] ($idemotion) a audience $id <br/>";	
}

//removing
if ($flag == "remove"){
	$sql_add = "DELETE FROM `audience_has_emotion` WHERE `audience_has_emotion`.`idaudience` = '$id' AND `emotion` = '$idemotion' ";
	/*if (!(mysql_select_db("my_labintdoppiogioco",$connessione)))
		die("Data base non trovato!");*/	
	if (!($result = mysqli_query($connessione, $sql_add)))
			die("Non riesco a togliere questa emozione dalla persona selezionata");  
	echo "tolta emozione $array_emonames[$idemotion] ($idemotion) alla persona con id $id <br/>";			
}

//change
if (($flag == "change")&&(isset($_REQUEST["file"]))){
	$file = $_REQUEST["file"];
	$sql_add = "UPDATE `audience_has_emotion` SET `URI` = '$file' WHERE `audience_has_emotion`.`idaudience` = '$id' AND `emotion` = '$idemotion' ";
	/*if (!(mysql_select_db("my_labintdoppiogioco",$connessione)))
		die("Data base non trovato!");*/	
	if (!($result = mysqli_query($connessione, $sql_add)))
			die("Non riesco a modificare questa emozione dalla persona selezionata");  
	echo "modificata emozione $array_emonames[$idemotion] ($idemotion) alla persona con id $id <br/>";			
}


//then generates the controls for the changing/removing the existing emotions 
//and for the controls for adding the missing ones



$lista_emozioni = getAudienceEmotions($id,$connessione);
//echo "lista emozioni:";
//print_r($lista_emozioni);
//echo "<br /><br />";

$lista_files = getAudienceEmotionFiles($id,$connessione);
//echo "lista files:";
//print_r($lista_files);
//echo "<br /><br />";

$diff = array_diff($array_emonames,$lista_emozioni);

array_shift($diff);
//print_r ($diff);

echo "<form name=\"form1\">";

$counter = 0;

foreach ($lista_emozioni as $e){
	$idemotion = $array_emotions[$e];
	//mettere IMG qui
	echo "$e";
	//echo "file: $lista_files[$e]";
	echo "<img  style=\"max-width:100px; max-height:100px \" src=\"../audience/$lista_files[$e]\">";
	//echo "file ($lista_files[$e])";	
	$idemotion = $array_emotions[$e];	
	echo "<input type=\"file\" value=\"scegli un nuovo file\" id=\"select$counter\" name=\"photo\" /> ";
	echo "<input type=\"button\" value=\"carica il file\" onclick=\"inviaForm('select$counter');\" />";
	echo "<input type=\"button\" value=\"modifica l'emozione\" onclick=\"manageEmotion($id,$idemotion,'change')\" /> ";
	echo "<input type=\"button\" value=\"cancella l'emozione\" onclick=\"manageEmotion($id,$idemotion,'remove')\" />  <br/>";	
	$counter++;
}


echo "<p>Aggiungi una nuova emozione:</p>";

//echo "</form name=\"emozioni2\" id=\"emozioni2\">";


$counter = 0;

foreach ($diff as $i){	
		echo "$i ";
		$idemotion = $array_emotions[$i];
		//echo "<input type=\"button\" onclick=\"manageEmotion($id,$array_emotions[$i],'add')>$i</option>";
		echo "<input type=\"file\" value=\"scegli un nuovo file\" id=\"fileselect$counter\" name=\"photo1\" /> ";
		echo "<input type=\"button\" value=\"carica il file\" onclick=\"inviaForm('fileselect$counter');\" />";
		echo "<input type=\"button\" value=\"aggiungi l'emozione\" onclick=\"manageEmotion($id,$idemotion,'add')\" />" ;
		echo "<br />";		
		$counter++;
}	

echo "</form>";



?>