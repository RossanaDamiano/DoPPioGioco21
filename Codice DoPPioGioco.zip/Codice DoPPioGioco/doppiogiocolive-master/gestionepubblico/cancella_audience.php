<?php

include '../include/connessione.php';
include '../include/utilities.php';


$chi = $_REQUEST["nome"];

if (!($connessione = mysqli_connect($host, $username, $password)))
	die("Connessione fallita!");

if (!(mysqli_select_db($connessione, $db)))
	die("Data base non trovato!");

$sql = "DELETE FROM `audience` WHERE `audience`.`id_audience` = $chi";

if (!($result = mysqli_query($connessione, $sql)))
		die("Non riesco cancellare questa persona dal pubblico");  
	
$sql = "DELETE FROM `audience_has_emotion` WHERE `audience_has_emotion`.`idaudience` = $chi";


if (!($result = mysqli_query($connessione, $sql)))
		die("Non riesco cancellare le emozioni di questa persona del pubblico");  

echo "Cancellazione effettuata";

?>