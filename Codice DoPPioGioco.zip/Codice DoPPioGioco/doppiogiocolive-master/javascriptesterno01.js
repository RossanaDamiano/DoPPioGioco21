// JavaScript Document

function nuovaSessione(){
    var data={
        operation : "session",
        utente : "labint1819"
    };

    $.ajax({
        type: "GET",
        url: 'newEngine/php/scriptDB.php',
        data: data,
        success: function(data){
            console.log(data);
            var session = JSON.parse(data);
            //alert(session[0]["sessione"]);
            var output = "<tr><td>Director's tools</td><td>&nbsp;</td></tr>"+
                    "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>"+
                    "<tr><td></td><td><a href=\"newEngine/console.html?session="+session[0]["sessione"]+"\" target=\"_blank\">Console</a></td></tr>"+
                    "<tr><td></td><td><a id=\"a_clip\" target=\"_blank\" style=\"font-size: 10pt\">Clip</a></td></tr>"+
                    "<tr><td></td><td><a id=\"a_note\" target=\"_blank\" style=\"font-size: 10pt\">Notes</a></td></tr>"+
                    "<tr><td></td><td><a id=\"a_emotion\" target=\"_blank\" style=\"font-size: 10pt\">Emotion</a></td></tr>";
            $("#table-href").html(output);
            var regia = "<tr><td>Regia</td><td>&nbsp;</td></tr>"+
                        "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>"+
                        "<tr><td></td><td><a id=\"a_regia\" target=\"_blank\" style=\"font-size: 10pt\">Monitor Regia</a></td></tr>"+
                        "<tr><td></td><td><a id=\"a_regiaProva\" target=\"_blank\" style=\"font-size: 10pt\">Monitor Regia without public</a></td></tr>";
            $("#regia").html(regia);
           
            var data2 = {
                utente : "labint1819",
                operation : "getSession",
                timestamp : ""+session[0]['timestamp']
            };

            socket.on('startsessionmsg', function(msg){
                console.log("ricevuto messaggio di inizio sessione: " + msg);

                $.ajax({
                    type: "GET",
                    url: 'newEngine/php/scriptDB.php',
                    data: data2,
                    success: function(data){
                        var id = JSON.parse(data);
                        //alert(id[0]['sessione']);
                        document.getElementById("a_clip").setAttribute("href", "newEngine/clipt.html?session="+id[0]["sessione"]);
                        document.getElementById("a_note").setAttribute("href", "newEngine/notes.html?session="+id[0]["sessione"]);
                        document.getElementById("a_emotion").setAttribute("href", "newEngine/emotion.html?session="+id[0]["sessione"]);
                        document.getElementById("a_regia").setAttribute("href", "newEngine/regia.html?session="+id[0]["sessione"]);
                        document.getElementById("a_regiaProva").setAttribute("href", "newEngine/regiaPubblicoFinto.html?session="+id[0]["sessione"]);
                    }
                });    
            });
        }
    });
}

function scaleSize(source){
  window.alert(source); //d_height,i_width,i_height);
  var clip_img = new Image();
  clip_img.src=source;
  var i_height = clip_img.height(); var i_width = clip_img.width();
  var d_height = $("#clipscreen").height(); var d_width = $("#clipscreen").width();
  window.alert(d_width); //d_height,i_width,i_height);
  if (i_width <= d_width || i_height <= d_height) {
    var ratio = min (d_width/i_width, d_height/i_height);
    i_width = ratio * d_width;
    i_height = ratio * d_height;
  } else {
    var ratio = min (i_width/d_width, i_height/d_height);
    i_width = ratio * d_width;
    i_height = ratio * d_height;
  }
  return [i_width, i_height];
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}


//js per video
function MM_CheckFlashVersion(reqVerStr,msg){
  with(navigator){
    var isIE  = (appVersion.indexOf("MSIE") != -1 && userAgent.indexOf("Opera") == -1);
    var isWin = (appVersion.toLowerCase().indexOf("win") != -1);
    if (!isIE || !isWin){
      var flashVer = -1;
      if (plugins && plugins.length > 0){
        var desc = plugins["Shockwave Flash"] ? plugins["Shockwave Flash"].description : "";
        desc = plugins["Shockwave Flash 2.0"] ? plugins["Shockwave Flash 2.0"].description : desc;
        if (desc == "") flashVer = -1;
        else{
          var descArr = desc.split(" ");
          var tempArrMajor = descArr[2].split(".");
          var verMajor = tempArrMajor[0];
          var tempArrMinor = (descArr[3] != "") ? descArr[3].split("r") : descArr[4].split("r");
          var verMinor = (tempArrMinor[1] > 0) ? tempArrMinor[1] : 0;
          flashVer =  parseFloat(verMajor + "." + verMinor);
        }
      }
      // WebTV has Flash Player 4 or lower -- too low for video
      else if (userAgent.toLowerCase().indexOf("webtv") != -1) flashVer = 4.0;

      var verArr = reqVerStr.split(",");
      var reqVer = parseFloat(verArr[0] + "." + verArr[2]);

      if (flashVer < reqVer){
        if (confirm(msg))
          window.location = "http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash";
      }
    }
  }
}

//var switch1 = 'clip';
var image_loaded = 'false';

//check viene settato a 1 quando la unit viene creata
function switchCreation(unit,value,type){
	if (document.getElementById('check').value == 1){
		modificaElementoInUnit(unit,value,type);
	} else {
		creaUnit(value);
	}
}

function creaUnit(title) {
    if (title == "scrivi un titolo") {
        document.getElementById('title').innerHTML = "devi scrivere un titolo";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                if (xmlhttp.responseText == 'doppione'){document.getElementById('title').innerHTML = 'esiste già una unit con questo titolo';} else {
                	document.getElementById('title').innerHTML = title;
                	document.getElementById('mio_id').value = xmlhttp.responseText;
                	document.getElementById('tit').innerHTML = 'nuovo titolo';
                	document.getElementById('pulsantecrea').value = "modifica";
                	document.getElementById('check').value = 1;
                	document.getElementById('ewarn').innerHTML = "";
                	document.getElementById('initial').innerHTML = "";
                	document.getElementById('final').innerHTML = "";
                	document.getElementById('notes').innerHTML = "";
                	}
            }
        }
        xmlhttp.open("GET","creaUnitBasic.php?title="+title,true);
        xmlhttp.send();
    }
}


function modificaElementoInUnit(unit,value,type) {
    if (document.getElementById('check').value == 0) {
        document.getElementById(type).innerHTML = "prima devi creare la unit";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById(type).innerHTML = xmlhttp.responseText;
                if (type == 'notes'){
                	if (document.getElementById('clippy').src == "")
                	{document.getElementById('notes_mirror').innerHTML = xmlhttp.responseText;}

                }
            }
        }
        xmlhttp.open("GET","modificaUnit.php?unit="+unit+"&"+"type="+type+"&"+"value="+value,true);
        xmlhttp.send();
    }
}

function ripristinaImmagine(my_file) {
  img = new Image();
  img.id = 'clippy';
	img.src = 'file';
}


function changeEmotion(unit,emotion,flag,dove) {
    if (document.getElementById('check').value == 0) {
        document.getElementById('ewarn').innerHTML = " <br/>prima devi creare la unit!";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById(dove).innerHTML = xmlhttp.responseText;
                //forse non serve
                //document.getElementById(dove).checked = flag;
            }
        }
        xmlhttp.open("GET","modificaEmozione.php?unit="+unit+"&"+"emotion="+emotion+"&"+"flag="+flag,true);
        xmlhttp.send();
    }
}

function putInStory(clip,unit) {
    if (document.getElementById('check').value == 0) {
        document.getElementById("unit_dopo").innerHTML = "non ho aggiunto nulla";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("unit_dopo").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","inserisci_unit_in_storia.php?after="+clip+"&"+"before="+unit,true);
        xmlhttp.send();
    }
}

function removeFromStory(clip,unit,nuova) {
    if (document.getElementById('check').value == 0) {
        document.getElementById("unit_dopo").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("unit_dopo").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","cancellaDaStoryGraph.php?before="+clip+"&"+"after="+unit+"&"+"nuova="+nuova,true);
        xmlhttp.send();
    }
}

var form = document.getElementById('file-form');
var fileSelect = document.getElementById('file-select');
//var uploadButton = document.getElementById('upload-button');
var pulsante = document.getElementById('pulsante');


//form.onsubmit = function(event)
//pulsante.onclick = function(event)
function inviaForm(idunit)
	{
		if (document.getElementById('check').value == 0){return;}
  	//event.preventDefault();
  	// Get the selected files from the input.
	//var files = fileSelect.files;
	var files = document.getElementById('file-select').files;
	// Create a new FormData object.
	var formData = new FormData();
  	// Loop through each of the selected files.
	for (var i = 0; i < files.length; i++) {
  		var file = files[i];
  		// Check the file type.
  		if (!file.type.match('image.*')) {
    	continue;
  		}
  		// Add the file to the request.
  		formData.append('photo', file, file.name);
  	  	// Files
		formData.append(name, file, file.name);
		// Blobs
		//formData.append(name, blob, file.name);
		// Strings
		formData.append('unit', idunit);
	}
	// Set up the request.
	var xhr = new XMLHttpRequest();
  	// Open the connection.
	xhr.open('POST', 'upload_async.php', true);
	// Set up a handler for when the request finishes.
	xhr.onreadystatechange = function () {
  	if (xhr.status === 200) {
    	// File(s) uploaded.
    	//uploadButton.innerHTML = 'Upload';
    	//document.getElementById('caricamento').innerHTML = xhr.responseText;

    	/*
    	if (document.getElementById('clippy')) {document.getElementById('clippy').src = ''}
    	document.getElementById('clipscreen').innerHTML = xhr.responseText;
    	*/
        var immagine = xhr.responseText.trim();
		if (immagine != 'fail'){
        	//alert ('tutto bene');
    		document.getElementById('clippy').src = xhr.responseText;
    		//document.getElementById('notes_mirror').innerHTML = '';

    		//document.getElementById('switch-clip').innerHTML = '';
    		image_loaded = 'true';
    		document.getElementById('mia_immagine').value = xhr.responseText;
  			} else {alert('Errore di  caricamento!');}
        
        } else {
    		alert('An error occurred!');
  			}
		};
  	// Send the Data.
	xhr.send(formData);
}


function cancellaClip(unit) {
    if (document.getElementById('check').value == 0) {
        //document.getElementById("unit_dopo").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                //document.getElementById("unit_dopo").innerHTML = xmlhttp.responseText;
            //document.load();
            }
        }
        xmlhttp.open("GET","cancellaDaStoryGraph.php?before="+clip+"&"+"after="+unit+"&"+"nuova="+nuova,true);
        xmlhttp.send();
    }
}


//cancellaUnit
//cancella_unit.php?id=

function cancellaUnit(id) {
    if (document.getElementById('info-delete').innerHTML == 'deleted') {
        //document.getElementById("unit_dopo").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.status == 200) {
                //document.getElementById("unit_dopo").innerHTML = xmlhttp.responseText;
            //document.load();
            //document.getElementById("info-delete").innerHTML = xmlhttp.responseText;
            //alert("unit " + id + " cancellata!");
  			document.getElementById("clippy").src = '';
  			//document.getElementById('notes_mirror').innerHTML = '';
  			document.getElementById("title").innerHTML = 'deleted';
  			document.getElementById("tit").value = '';
        document.getElementById("notes1").innerHTML = '';
        document.getElementById("notes2").value= '';
  			document.getElementById("initial").innerHTML = '';
  			document.getElementById("final").innerHTML = '';

            }
        }
        xmlhttp.open("GET","cancella_unit.php?id="+id,true);
        xmlhttp.send();
    }
}

function trovaUnit(unit,response,sessione,decisione,intensity) {
    if (unit == "") {
        document.getElementById("scelta").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("scelta").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","trovaContinuazioni.php?unit="+unit+"&"+"response="+response+"&"+"sessione="+sessione+"&"+"decisione="+decisione+"&"+"intensity="+intensity, true);
        xmlhttp.send();
    }
}
