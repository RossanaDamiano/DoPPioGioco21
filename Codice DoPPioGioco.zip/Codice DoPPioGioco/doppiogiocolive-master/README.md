Interactive Storytelling --> DoPPioGioco
========

- [Installazione](#installazione)
- [Configurazione](#configurazione)

### Introduzione

Progetto di ricerca: “PIZA_CRT_17_01 Officine Sintetiche IX edizione”.

Obiettivo: ingegnerizzazione dell'applicazione web di interactive Storytelling denominata DoPPioGioco.

## [Installazione](#installazione)

Per far girare la piattaforma è necessario aver installato nella macchina:

#### Docker

* [Windows](https://docs.docker.com/windows/started)
* [OS X](https://docs.docker.com/mac/started/)
* [Linux](https://docs.docker.com/linux/started/)

Nello specifico viene utilizzato **docker compose**, uno strumento per la definizione e l'esecuzione di applicazioni Docker multi-contenitore.

Nel file **docker-compose.yml** sono stati definiti tutti i contenitori che serviranno:
1. web (pagine web)
2. php (versione 7.2.10)
3. db (database)
4. phpmyadmin (gestione del database)
5. socket (per la comunicazione tra le pagine web)

Sempre in questo file vengono settate nell'indirizzo web le porte per accedere all'applicazione (localhost:8080) e al database (localhost:8082).

```yml
web:
    image: nginx:latest
    ports:
      - "8080:80"
    volumes:
      - ./:/code
      - ./site.conf:/etc/nginx/conf.d/default.conf
    links:
      - php
...

phpmyadmin:
    image: phpmyadmin/phpmyadmin
    links:
      - db:db
    ports:
      - "8082:80"
    environment:
      MYSQL_USERNAME: root
      MYSQL_ROOT_PASSWORD: root
    depends_on: 
      - db
```

Come web server dell'applicazione viene utilizzato **NGINX** e creato il file *site.conf* dove viene riportata la pagina index del progetto.

![siteConf](/uploads/aa7cff1e565a631e2eec42b23aa6a885/siteConf.png)

## [Configurazione](#configurazione)

Tramite il terminale, si accede alla cartella che contiene il file **docker-compose.yml** e si procede con i seguenti comandi:
1. Creazione dei servizi

```
sudo docker-compose build
```
2. Aggregazione dell'output di ogni contenitore, se sono presenti contenitori per un servizio e la configurazione o l'immagine del servizio è stata modificata dopo la creazione del contenitore, questo raccoglie le modifiche arrestando e ricreando i contenitori (mantenendo i volumi montati)
```
sudo docker-compose up
```
3. Se si vuole interrompere il processo, usare il comando **ctrl + C**, i contenitori vengono arrestati con codice di uscita 0

4. Una volta terminato l'utilizzo dell'applicazione, si procede con il comando
```
sudo docker-compose down
```
Questo arresta i contenitori e rimuove contenitori, reti, volumi e immagini creati da 'up'.

#### Importare il database

Accedere alla pagina [http://localhost:8082](http://localhost:8082), nel file *docker-compose.yml* si trovano user e password per accedere al database.
A questo punto basta creare e importare il database **my_labinterdisciplinare1516.sql**.

#### Run dell'applicazione

Aprire il browser Firefox e digitare l'url: [http://localhost:8080](http://localhost:8080), comparirà così la pagina *index*

![schermataHome](/uploads/18dd541bf6d2ddb22ee66fc0bea55110/schermataHome.png)

#### Utilizzo della piattaforma su più PC

Per poter accedere alla piattaforma tramite PC diversi, bisogna utilizzare al posto di *http://localhost:8080*, l'indirizzo della macchina che contiene il codice dell'applicazione, ad esempio *192.168.178.132:8080*


Per sapere l'indirizzo di questa macchina, bisogna scrivere sul terminale il seguente comando:

* per Windows
```
ipconfig
```
* per OS X e per Linux
```
ifconfig
```

Esempio su Linux
![commandIP](/uploads/a1d1301908882743b00d9de6ede83f9b/commandIP.png)

Una volta ottenuto l'indirizzo bisogna aprire i seguenti file dell'applicazione:
- clipt.html
- consoleapp.js
- emotion.html
- notes.html
- regia.html
- regiaPubblicoFinto.html

In queste pagine si trovano le seguenti linee di codice
```javascript
    const socket = io('http://localhost:14080');
    socket.on('connect', function(){
        console.log("Connessione stabilita globale");
    });
```
queste vengono utilizzate dal socket per connettersi e poter scambiare i messaggi con le altre pagine connesse allo stesso indirizzo;

al posto della riga "*const socket = io('http://localhost:14080');*" si inserisce l'indirizzo della macchina trovato in precedenza.

Seguendo sempre l'esempio sopra diventa "*const socket = io('http://192.168.178.132:14080');*".